<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>Question 10 btn</name>
   <tag></tag>
   <elementGuidId>4294d10c-625b-4576-9a55-3a14cdc3f550</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>((//div[text()='10'])[1]//parent::div[1])[1]</value>
      </entry>
      <entry>
         <key>BASIC</key>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <smartLocatorEnabled>false</smartLocatorEnabled>
   <useRalativeImagePath>false</useRalativeImagePath>
</WebElementEntity>
