<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>Dropdown Choice 1</name>
   <tag></tag>
   <elementGuidId>4ffd33a7-2028-4704-abf3-ddf80384235b</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>((//div[text()='Choices'])[3]//following::input[@placeholder='Option 1'])[1]</value>
      </entry>
      <entry>
         <key>BASIC</key>
         <value></value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <smartLocatorEnabled>false</smartLocatorEnabled>
   <useRalativeImagePath>false</useRalativeImagePath>
</WebElementEntity>
