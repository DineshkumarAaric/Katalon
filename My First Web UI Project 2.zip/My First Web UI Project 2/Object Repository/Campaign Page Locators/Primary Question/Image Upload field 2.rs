<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>Image Upload field 2</name>
   <tag></tag>
   <elementGuidId>f8340dbe-9133-4ee7-957c-e6605320d5fc</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>((//input[@type='file'])//following::input[@type='text'])[2]</value>
      </entry>
      <entry>
         <key>BASIC</key>
         <value></value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <smartLocatorEnabled>false</smartLocatorEnabled>
   <useRalativeImagePath>false</useRalativeImagePath>
</WebElementEntity>
