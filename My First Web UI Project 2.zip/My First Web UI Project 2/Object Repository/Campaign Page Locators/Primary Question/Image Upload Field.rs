<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>Image Upload Field</name>
   <tag></tag>
   <elementGuidId>e4d4c011-a63b-40e0-b1e7-c70f6930a899</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>((//input[@type='file'])//following::input[@type='text'])[1]</value>
      </entry>
      <entry>
         <key>BASIC</key>
         <value></value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <smartLocatorEnabled>false</smartLocatorEnabled>
   <useRalativeImagePath>false</useRalativeImagePath>
</WebElementEntity>
