<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>div_QuestionDynamic Field</name>
   <tag></tag>
   <elementGuidId>f66299d5-5061-4307-8d57-29100b33d8b5</elementGuidId>
   <selectorCollection>
      <entry>
         <key>CSS</key>
         <value>div.ant-collapse-content.ant-collapse-content-active > div.ant-collapse-content-box > div.sc-krKvcV.euxeqF</value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>//div[@id='page-container']/div[2]/div[2]/div[3]/div[2]/span/div/div/div[4]/div[2]/div/div[2]/div/div</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <smartLocatorEnabled>false</smartLocatorEnabled>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>div</value>
      <webElementGuid>3659e0fc-c0a8-49a6-950f-0306f1ff7d74</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>sc-krKvcV euxeqF</value>
      <webElementGuid>6e96dc89-7841-4b2e-9ff1-284a22d01e00</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>QuestionDynamic Field                  Upload Question﻿XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX  RequiredQuestion TypeUpload QuestionAllowable File Typesjpgpngdocxlsxcsv xlsxcsvjpgpngdocxlsxcsvFormat PreviewQ4.  Drag and Drop an image or  Browse (Accepted Files: jpg,png,doc,xlsx,csv)</value>
      <webElementGuid>e4c424c8-d07c-4e15-b0be-cfd6f5c4a0b1</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;page-container&quot;)/div[@class=&quot;sc-bfdVwy egDjvI&quot;]/div[@class=&quot;sc-FaLkm kcSEUl&quot;]/div[@class=&quot;ant-card ant-card-bordered sc-iMGUdT kynnSF&quot;]/div[@class=&quot;ant-card-body&quot;]/span[@class=&quot;sc-kPpJbQ hrykxW&quot;]/div[@class=&quot;sc-cBaIQL jlxEYs&quot;]/div[@class=&quot;sc-jVCHgA knqiGU&quot;]/div[@class=&quot;sc-hKgILt sc-fsRnyX iJJCRx bcuYfa&quot;]/div[@class=&quot;ant-collapse ant-collapse-icon-position-end ant-collapse-borderless sc-gtTazr bFYtiq&quot;]/div[@class=&quot;ant-collapse-item ant-collapse-item-active sc-dxysmu jHCMiG&quot;]/div[@class=&quot;ant-collapse-content ant-collapse-content-active&quot;]/div[@class=&quot;ant-collapse-content-box&quot;]/div[@class=&quot;sc-krKvcV euxeqF&quot;]</value>
      <webElementGuid>1cc69dc1-131c-4a5d-a525-e7a7dcd6a66d</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//div[@id='page-container']/div[2]/div[2]/div[3]/div[2]/span/div/div/div[4]/div[2]/div/div[2]/div/div</value>
      <webElementGuid>9a26533e-d047-4da2-9b3b-97f190664e1b</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Required'])[4]/following::div[9]</value>
      <webElementGuid>873dd148-8f74-4388-9ea0-d93ad710a392</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Upload'])[1]/following::div[11]</value>
      <webElementGuid>7b50fb31-4797-4ba6-8223-670a7dee5f4a</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//div[4]/div[2]/div/div[2]/div/div</value>
      <webElementGuid>211f9b9f-716e-4e60-b7cd-498dbed0cebd</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//div[(text() = 'QuestionDynamic Field                  Upload Question﻿XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX  RequiredQuestion TypeUpload QuestionAllowable File Typesjpgpngdocxlsxcsv xlsxcsvjpgpngdocxlsxcsvFormat PreviewQ4.  Drag and Drop an image or  Browse (Accepted Files: jpg,png,doc,xlsx,csv)' or . = 'QuestionDynamic Field                  Upload Question﻿XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX  RequiredQuestion TypeUpload QuestionAllowable File Typesjpgpngdocxlsxcsv xlsxcsvjpgpngdocxlsxcsvFormat PreviewQ4.  Drag and Drop an image or  Browse (Accepted Files: jpg,png,doc,xlsx,csv)')]</value>
      <webElementGuid>a8663fb7-2e7e-4fac-8d0d-0042940dc6d3</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
