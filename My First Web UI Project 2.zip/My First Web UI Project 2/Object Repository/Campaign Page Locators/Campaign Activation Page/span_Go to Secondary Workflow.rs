<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>span_Go to Secondary Workflow</name>
   <tag></tag>
   <elementGuidId>8032cf38-5eb1-4789-8dd3-7db7d1ffbad8</elementGuidId>
   <selectorCollection>
      <entry>
         <key>CSS</key>
         <value>span.sc-hHUFbR.BxSVb</value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>(//div[@class='ant-steps-item-container'])[2]</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <smartLocatorEnabled>false</smartLocatorEnabled>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>span</value>
      <webElementGuid>6328417d-7855-4fa3-b023-cc4ffaac706a</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>sc-hHUFbR BxSVb</value>
      <webElementGuid>678a08ad-ae3a-4860-9127-c475307c0686</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>Go to Secondary Workflow</value>
      <webElementGuid>a84cda5f-4a1e-4dca-b5e6-63199b9018f7</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;page-container&quot;)/div[@class=&quot;sc-bfdVwy egDjvI&quot;]/div[@class=&quot;sc-FaLkm kcSEUl&quot;]/div[@class=&quot;ant-card ant-card-bordered sc-iMGUdT kynnSF&quot;]/div[@class=&quot;ant-card-head&quot;]/div[@class=&quot;ant-card-head-wrapper&quot;]/div[@class=&quot;ant-card-head-title&quot;]/div[@class=&quot;sc-hKgILt fMWbrt&quot;]/div[@class=&quot;sc-cjLdud UIFld&quot;]/div[@class=&quot;sc-hKgILt WxKTo&quot;]/span[@class=&quot;sc-hHUFbR BxSVb&quot;]</value>
      <webElementGuid>cf7fb827-41c4-4aa2-ae1e-8f93e8459259</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//div[@id='page-container']/div[2]/div[2]/div[3]/div/div/div/div/div/div/span</value>
      <webElementGuid>9262224f-8df8-4e28-9829-f439a1933659</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Primary Questions'])[2]/following::span[1]</value>
      <webElementGuid>15f717c0-be1f-43e9-b972-ab8ed346cf87</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Setup Configuration'])[1]/following::span[2]</value>
      <webElementGuid>59ffdb4a-6b6b-4d67-a6c0-71507be10017</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Please leave your ratings for this survey.'])[1]/preceding::span[1]</value>
      <webElementGuid>2966a11d-44c6-493f-a087-5f4292120cbe</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Rating Scale'])[1]/preceding::span[1]</value>
      <webElementGuid>6b9b6539-28c7-4ca6-a25d-5d54b36c099c</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>//*/text()[normalize-space(.)='Go to']/parent::*</value>
      <webElementGuid>1aa10220-0841-4b9d-a878-886ca2844f10</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//div[3]/div/div/div/div/div/div/span</value>
      <webElementGuid>4a73dc74-ce96-4765-9caf-add5f7f476fc</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//span[(text() = 'Go to Secondary Workflow' or . = 'Go to Secondary Workflow')]</value>
      <webElementGuid>4c7a02bd-a95b-4e1d-8fc9-5086dc706951</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
