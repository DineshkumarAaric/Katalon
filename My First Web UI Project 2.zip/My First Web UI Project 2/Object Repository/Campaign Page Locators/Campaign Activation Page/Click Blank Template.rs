<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>Click Blank Template</name>
   <tag></tag>
   <elementGuidId>128e9d91-e288-4d3e-aa15-d6e1f698fce4</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>//div[@id='campaign_drawer_chooseTemplate_contentTemplate']//button[1]</value>
      </entry>
      <entry>
         <key>CSS</key>
         <value>button.ant-btn.ant-btn-primary.sc-jxqDtb.kBVtWp > span</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <smartLocatorEnabled>false</smartLocatorEnabled>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>span</value>
      <webElementGuid>93c197e2-97e5-4cf4-bbd1-d7d91a06757b</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>Use Template</value>
      <webElementGuid>3edae386-490e-4046-8809-109690d04c87</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;campaign_drawer_chooseTemplate_contentTemplate&quot;)/div[@class=&quot;sc-hKgILt sc-gPfNmV kBgJPZ dfNPkY&quot;]/div[@class=&quot;sc-cuyEII bMavgC&quot;]/button[@class=&quot;ant-btn ant-btn-primary sc-jxqDtb kBVtWp&quot;]/span[1]</value>
      <webElementGuid>b69fd262-7783-4bd0-8bf4-84c5e7a62b09</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//div[@id='campaign_drawer_chooseTemplate_contentTemplate']/div/div[5]/button/span</value>
      <webElementGuid>2e08916a-ff85-4810-b4ec-0efdcbbd0cd2</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Template for Blank Template'])[1]/following::span[1]</value>
      <webElementGuid>b909b030-780c-4ee4-8a38-9d25f6301f6b</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Blank Template'])[1]/following::span[1]</value>
      <webElementGuid>f1fbaf6a-29eb-4f63-a7e2-86979b0629ea</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Post Close: Standard'])[1]/preceding::span[1]</value>
      <webElementGuid>e9c2396d-06c7-4fd7-82d9-08130f6b1e20</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Use Template'])[2]/preceding::span[1]</value>
      <webElementGuid>7ac5ca4e-6d0b-4a57-9db4-23edd661be68</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>//*/text()[normalize-space(.)='Use Template']/parent::*</value>
      <webElementGuid>72f498f6-1293-49fc-87f2-81c6fbc1fadd</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//div/div/div[5]/button/span</value>
      <webElementGuid>ef6310ed-af12-4dc5-a94c-177efb8f7760</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//span[(text() = 'Use Template' or . = 'Use Template')]</value>
      <webElementGuid>4ec52618-bcd5-4508-a79c-f7cdb291f2ee</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
