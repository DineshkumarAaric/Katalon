<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>span_Go to Email Setup</name>
   <tag></tag>
   <elementGuidId>aa81e014-e176-4691-a381-443450b0c47e</elementGuidId>
   <selectorCollection>
      <entry>
         <key>CSS</key>
         <value>span.sc-hHUFbR.BxSVb</value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>//div[@id='page-container']/div[2]/div[2]/div[3]/div/div/div/div/div/div/span</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <smartLocatorEnabled>false</smartLocatorEnabled>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>span</value>
      <webElementGuid>59b5f393-a658-4c73-9fd8-2e04902fd24e</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>sc-hHUFbR BxSVb</value>
      <webElementGuid>a5a5e404-4c1d-4623-a7d3-c1d738b9c94d</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>Go to Email Setup</value>
      <webElementGuid>10c56edf-0628-4645-aaff-8d4c8b09f1bc</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;page-container&quot;)/div[@class=&quot;sc-bfdVwy egDjvI&quot;]/div[@class=&quot;sc-FaLkm kcSEUl&quot;]/div[@class=&quot;ant-card ant-card-bordered sc-iMGUdT gzVqVd&quot;]/div[@class=&quot;ant-card-head&quot;]/div[@class=&quot;ant-card-head-wrapper&quot;]/div[@class=&quot;ant-card-head-title&quot;]/div[@class=&quot;sc-hKgILt fMWbrt&quot;]/div[@class=&quot;sc-cjLdud UIFld&quot;]/div[@class=&quot;sc-hKgILt WxKTo&quot;]/span[@class=&quot;sc-hHUFbR BxSVb&quot;]</value>
      <webElementGuid>9a793d29-3936-4444-8657-e91c347f16be</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//div[@id='page-container']/div[2]/div[2]/div[3]/div/div/div/div/div/div/span</value>
      <webElementGuid>3c78c5e6-5e26-40f1-9c6d-9886fd2c07f9</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Secondary Workflow'])[2]/following::span[1]</value>
      <webElementGuid>2a341444-45e1-4121-895a-64e85eea346c</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Setup Configuration'])[1]/following::span[2]</value>
      <webElementGuid>91caa972-1da7-4c98-b04b-969b3dd67698</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Great'])[1]/preceding::span[1]</value>
      <webElementGuid>988d6744-dead-43f4-896e-59a2931f1ca7</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>//*/text()[normalize-space(.)='Go to']/parent::*</value>
      <webElementGuid>e056041f-b61a-45bc-96bc-a399f310d27f</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//div[3]/div/div/div/div/div/div/span</value>
      <webElementGuid>f2e669cc-66d0-4ea9-a757-892efa43dd10</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//span[(text() = 'Go to Email Setup' or . = 'Go to Email Setup')]</value>
      <webElementGuid>5b22c62f-ae07-4190-9b46-1a5c9c5e9ec2</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
