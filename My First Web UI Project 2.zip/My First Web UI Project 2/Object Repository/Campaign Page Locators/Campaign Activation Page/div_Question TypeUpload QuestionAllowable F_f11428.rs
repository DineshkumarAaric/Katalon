<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>div_Question TypeUpload QuestionAllowable F_f11428</name>
   <tag></tag>
   <elementGuidId>3588570f-e637-44bb-b90e-f365f7647db2</elementGuidId>
   <selectorCollection>
      <entry>
         <key>CSS</key>
         <value>div.ant-collapse-content.ant-collapse-content-active > div.ant-collapse-content-box > div.sc-krKvcV.euxeqF > div.sc-hKgILt.ePffiV</value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>//div[@id='page-container']/div[2]/div[2]/div[3]/div[2]/span/div/div/div[10]/div[2]/div/div[2]/div/div/div[4]</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <smartLocatorEnabled>false</smartLocatorEnabled>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>div</value>
      <webElementGuid>d7643b04-9699-4e18-864a-196a0c014055</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>sc-hKgILt ePffiV</value>
      <webElementGuid>f77e1375-2cf3-4a75-ad5c-6c0cf52521e8</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>Question TypeUpload QuestionAllowable File Typesjpgpngdocxlsxcsv docxlsxcsvjpgpngdocxlsxcsv</value>
      <webElementGuid>a5416b08-7cdb-4dec-af97-091f01a409b6</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;page-container&quot;)/div[@class=&quot;sc-bfdVwy egDjvI&quot;]/div[@class=&quot;sc-FaLkm kcSEUl&quot;]/div[@class=&quot;ant-card ant-card-bordered sc-iMGUdT kynnSF&quot;]/div[@class=&quot;ant-card-body&quot;]/span[@class=&quot;sc-kPpJbQ hrykxW&quot;]/div[@class=&quot;sc-cBaIQL jlxEYs&quot;]/div[@class=&quot;sc-jVCHgA knqiGU&quot;]/div[@class=&quot;sc-hKgILt sc-fsRnyX iJJCRx bcuYfa&quot;]/div[@class=&quot;ant-collapse ant-collapse-icon-position-end ant-collapse-borderless sc-gtTazr bFYtiq&quot;]/div[@class=&quot;ant-collapse-item ant-collapse-item-active sc-dxysmu jHCMiG&quot;]/div[@class=&quot;ant-collapse-content ant-collapse-content-active&quot;]/div[@class=&quot;ant-collapse-content-box&quot;]/div[@class=&quot;sc-krKvcV euxeqF&quot;]/div[@class=&quot;sc-hKgILt ePffiV&quot;]</value>
      <webElementGuid>ea62b36b-c1ef-4d9a-a649-557cc6a79fc9</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//div[@id='page-container']/div[2]/div[2]/div[3]/div[2]/span/div/div/div[10]/div[2]/div/div[2]/div/div/div[4]</value>
      <webElementGuid>860d02ef-6bb0-4eca-a3d6-b2a3b203b3f8</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Required'])[13]/following::div[1]</value>
      <webElementGuid>268acaeb-0c56-420a-b5ec-9953baf5d17a</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//div[10]/div[2]/div/div[2]/div/div/div[4]</value>
      <webElementGuid>61f29851-78d3-46d4-8e77-2355a5e58daa</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//div[(text() = 'Question TypeUpload QuestionAllowable File Typesjpgpngdocxlsxcsv docxlsxcsvjpgpngdocxlsxcsv' or . = 'Question TypeUpload QuestionAllowable File Typesjpgpngdocxlsxcsv docxlsxcsvjpgpngdocxlsxcsv')]</value>
      <webElementGuid>e340f74b-48cc-49a1-a46d-cca84bd18927</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
