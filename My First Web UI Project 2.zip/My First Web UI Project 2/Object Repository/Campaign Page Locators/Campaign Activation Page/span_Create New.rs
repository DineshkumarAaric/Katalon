<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>span_Create New</name>
   <tag></tag>
   <elementGuidId>52a75ae7-4a4d-414f-9eb6-0e11025e8e0a</elementGuidId>
   <selectorCollection>
      <entry>
         <key>CSS</key>
         <value>button.ant-btn.ant-btn-default.ant-btn-compact-item.ant-btn-compact-first-item > span</value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>//button[@class='ant-btn ant-btn-default ant-btn-compact-item ant-btn-compact-first-item']</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <smartLocatorEnabled>false</smartLocatorEnabled>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>span</value>
      <webElementGuid>f85b8d7d-b696-4a1f-bc9d-df6874a44b21</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>Create New</value>
      <webElementGuid>59569a51-d15a-4cc4-8453-8d6a1d405508</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;createMenu&quot;)/div[@class=&quot;ant-space-compact ant-space-compact-block ant-dropdown-button&quot;]/button[@class=&quot;ant-btn ant-btn-default ant-btn-compact-item ant-btn-compact-first-item&quot;]/span[1]</value>
      <webElementGuid>6d9bf1dc-ffa0-40fc-8acc-40a62a13b576</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//div[@id='createMenu']/div/button/span</value>
      <webElementGuid>e13df72b-4fdf-4433-a302-6b7a31a33870</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Activity Feeds'])[1]/following::span[6]</value>
      <webElementGuid>f3d196c5-12fb-4e67-93ac-00cda2ec5d50</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Incomplete Surveys'])[1]/following::span[6]</value>
      <webElementGuid>0706c45e-963e-4d93-8db5-b4070223d6b8</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Survey Campaign'])[1]/preceding::span[1]</value>
      <webElementGuid>e4898068-e12b-4612-937f-cc66b047ae87</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Email Campaign'])[1]/preceding::span[2]</value>
      <webElementGuid>8250d000-0082-499e-b0dd-322da6257edc</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>//*/text()[normalize-space(.)='Create New']/parent::*</value>
      <webElementGuid>1656e70a-4988-47ca-aee7-25b96358cd6b</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//div[3]/div/button/span</value>
      <webElementGuid>5a0a6b9e-bbc8-4065-ae53-ec7ba86308f0</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//span[(text() = 'Create New' or . = 'Create New')]</value>
      <webElementGuid>a04dc09d-eb37-4446-bf89-6838579be1fc</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
