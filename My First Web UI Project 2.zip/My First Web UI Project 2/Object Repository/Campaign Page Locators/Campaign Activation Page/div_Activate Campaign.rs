<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>div_Activate Campaign</name>
   <tag></tag>
   <elementGuidId>bb35b2ca-3e75-4439-a790-5224cdd28d50</elementGuidId>
   <selectorCollection>
      <entry>
         <key>CSS</key>
         <value>div.sc-hKgILt.ePffiV > div.sc-gKsewC.eTHlrw</value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>//button[@id='camp_publish_button']/div/div</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <smartLocatorEnabled>false</smartLocatorEnabled>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>div</value>
      <webElementGuid>3bba8c4e-7ed6-47df-a1a4-c48fb8381a02</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>sc-gKsewC eTHlrw</value>
      <webElementGuid>d6f8b3c4-e76d-493d-bf85-1dbc7ff26aab</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>Activate Campaign</value>
      <webElementGuid>11c7494f-fd82-4503-b3b7-b2dcfbc51293</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;camp_publish_button&quot;)/div[@class=&quot;sc-hKgILt ePffiV&quot;]/div[@class=&quot;sc-gKsewC eTHlrw&quot;]</value>
      <webElementGuid>7e88e470-adf0-4511-881c-c574b3492de3</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//button[@id='camp_publish_button']/div/div</value>
      <webElementGuid>c93849d3-455d-471a-a82e-fa99baee657e</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Close'])[2]/following::div[2]</value>
      <webElementGuid>571c1ef4-198b-46b6-8194-9d4350de70ed</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//button[2]/div/div</value>
      <webElementGuid>0b995ebb-bf4e-40fb-8afe-5ad3ad27eb7b</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//div[(text() = 'Activate Campaign' or . = 'Activate Campaign')]</value>
      <webElementGuid>f7dabedf-a9d1-4166-9dc7-a4669e98f09e</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
