<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>div_Multiple Choice</name>
   <tag></tag>
   <elementGuidId>65b16b9c-b992-4d6d-a64d-0cb27290e30f</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>((//div[(text() = 'Multiple Choice' or . = 'Multiple Choice')])[2]//parent::div[1])[1]</value>
      </entry>
      <entry>
         <key>CSS</key>
         <value>div.sc-cjLdud.fANNoj</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <smartLocatorEnabled>false</smartLocatorEnabled>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>div</value>
      <webElementGuid>fdd5cb8f-dced-4ddc-b05d-5c1c47ba0b54</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>sc-cjLdud fANNoj</value>
      <webElementGuid>53cbe8cf-cdbb-449a-8f29-a5ad8d216c3b</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>Multiple Choice</value>
      <webElementGuid>f1c98f41-87f1-4323-8c1a-177d22b2af91</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;page-container&quot;)/div[@class=&quot;sc-bfdVwy egDjvI&quot;]/div[@class=&quot;sc-FaLkm kcSEUl&quot;]/div[@class=&quot;ant-card ant-card-bordered sc-iMGUdT kynnSF&quot;]/div[@class=&quot;ant-card-body&quot;]/span[@class=&quot;sc-kPpJbQ hrykxW&quot;]/div[@class=&quot;sc-cBaIQL jlxEYs&quot;]/div[@class=&quot;ant-collapse ant-collapse-icon-position-end ant-collapse-borderless sc-fHHSrm bxOZue&quot;]/div[@class=&quot;ant-collapse-item ant-collapse-item-active sc-cNytvn bVyehQ&quot;]/div[@class=&quot;ant-collapse-content ant-collapse-content-active&quot;]/div[@class=&quot;ant-collapse-content-box&quot;]/div[@class=&quot;sc-ceLVMN krvcpf&quot;]/div[@class=&quot;sc-bCBFUB iECNdW&quot;]/div[@class=&quot;sc-hKgILt sc-ktxhKL iJJCRx dbtirJ&quot;]/div[@class=&quot;sc-hKgILt sc-hxczxO iJJCRx dNShxu&quot;]/div[@class=&quot;sc-cjLdud fANNoj&quot;]</value>
      <webElementGuid>740cb2fe-32fc-4d87-95f6-3ec408b2cde3</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//div[@id='page-container']/div[2]/div[2]/div[3]/div[2]/span/div/div[2]/div/div[2]/div/div[2]/div[2]/div/div/div</value>
      <webElementGuid>1b98ca48-b7b8-448c-97c6-481ead6289ae</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Select Question Type'])[1]/following::div[4]</value>
      <webElementGuid>04dccb3b-86ff-4273-8cf9-31123f123e94</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Add New Question'])[1]/following::div[9]</value>
      <webElementGuid>59046582-d8b4-44b8-8550-f877b943a5d8</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Matrix Question'])[1]/preceding::div[1]</value>
      <webElementGuid>ba460303-f815-4946-9334-0c1cb490867f</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Upload Question'])[1]/preceding::div[3]</value>
      <webElementGuid>740d18af-0286-49e5-ba5d-5eb72252b64d</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>//*/text()[normalize-space(.)='Multiple Choice']/parent::*</value>
      <webElementGuid>e88a3a31-225d-461a-bf68-59f659f92739</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//div/div[2]/div/div[2]/div/div[2]/div[2]/div/div/div</value>
      <webElementGuid>4bfaf33d-c107-4aa6-a3d5-ae631405c35d</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//div[(text() = 'Multiple Choice' or . = 'Multiple Choice')]</value>
      <webElementGuid>5127fcc3-d603-47b9-a17f-8f06e918d428</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
