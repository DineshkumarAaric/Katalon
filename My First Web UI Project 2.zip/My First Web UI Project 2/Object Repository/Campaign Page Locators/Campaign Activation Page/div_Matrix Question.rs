<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>div_Matrix Question</name>
   <tag></tag>
   <elementGuidId>da4d9495-0a46-4113-a7d3-b3e9804bc8b8</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>((//div[(text() = 'Matrix Question' or . = 'Matrix Question')])[2]//parent::div[1])[1]</value>
      </entry>
      <entry>
         <key>CSS</key>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <smartLocatorEnabled>false</smartLocatorEnabled>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>div</value>
      <webElementGuid>df32c227-9c03-4e0a-bcf4-d95b243b8aae</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>sc-hKgILt sc-hxczxO iJJCRx dNShxu</value>
      <webElementGuid>a473da7c-fff5-4372-b954-31ec075bf7eb</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>Matrix Question</value>
      <webElementGuid>fd10c493-f557-40bf-a15a-089a3cb1652a</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;page-container&quot;)/div[@class=&quot;sc-bfdVwy egDjvI&quot;]/div[@class=&quot;sc-FaLkm kcSEUl&quot;]/div[@class=&quot;ant-card ant-card-bordered sc-iMGUdT kynnSF&quot;]/div[@class=&quot;ant-card-body&quot;]/span[@class=&quot;sc-kPpJbQ hrykxW&quot;]/div[@class=&quot;sc-cBaIQL jlxEYs&quot;]/div[@class=&quot;ant-collapse ant-collapse-icon-position-end ant-collapse-borderless sc-fHHSrm bxOZue&quot;]/div[@class=&quot;ant-collapse-item ant-collapse-item-active sc-cNytvn bVyehQ&quot;]/div[@class=&quot;ant-collapse-content ant-collapse-content-active&quot;]/div[@class=&quot;ant-collapse-content-box&quot;]/div[@class=&quot;sc-ceLVMN krvcpf&quot;]/div[@class=&quot;sc-bCBFUB iECNdW&quot;]/div[@class=&quot;sc-hKgILt sc-ktxhKL iJJCRx dbtirJ&quot;]/div[@class=&quot;sc-hKgILt sc-hxczxO iJJCRx dNShxu&quot;]</value>
      <webElementGuid>46b320c6-8fc4-4eb0-96f4-44bb8038d796</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//div[@id='page-container']/div[2]/div[2]/div[3]/div[2]/span/div/div[2]/div/div[2]/div/div[2]/div[2]/div/div[2]</value>
      <webElementGuid>d3fb07c1-218e-4a5d-86c5-d13195bb1404</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Multiple Choice'])[3]/following::div[1]</value>
      <webElementGuid>400bbfc4-106d-43b6-8a8d-0dca56c2cbe5</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Select Question Type'])[1]/following::div[5]</value>
      <webElementGuid>1e5351df-2898-41cd-9417-2be5cbfe4403</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Upload Question'])[1]/preceding::div[2]</value>
      <webElementGuid>79d6c89c-0b3c-4ea7-9b6d-cdc39e582b24</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//div[2]/div/div[2]/div/div[2]/div[2]/div/div[2]</value>
      <webElementGuid>f5264522-32bb-41d8-a87e-c11a71a11986</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//div[(text() = 'Matrix Question' or . = 'Matrix Question')]</value>
      <webElementGuid>d9115fd3-aeb7-4719-b931-2d463a40c442</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
