<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>span_label is missing</name>
   <tag></tag>
   <elementGuidId>f9b20d35-be2c-4fa4-836c-18ae356645cc</elementGuidId>
   <selectorCollection>
      <entry>
         <key>CSS</key>
         <value>div.sc-hKgILt.sc-gewdXN.iJJCRx.iGAEoU > span.ant-typography.sc-fMQSxl.sc-hcIkuZ.gQSsiC.cWHGUW</value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>//div[@id='page-container']/div[2]/div[2]/div[3]/div[2]/span/div/div/div[9]/div[2]/div/div[2]/div/div/div[5]/div/div/div[2]/div/span</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <smartLocatorEnabled>false</smartLocatorEnabled>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>span</value>
      <webElementGuid>862d84df-a7da-4c2a-9cd6-179667109e6e</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>ant-typography sc-fMQSxl sc-hcIkuZ gQSsiC cWHGUW</value>
      <webElementGuid>97a32162-7c42-4e93-a71b-741748e06eb8</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>color</name>
      <type>Main</type>
      <value>#E04C4C</value>
      <webElementGuid>c92fb457-dc57-4678-a18a-3100c3186feb</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>label is missing</value>
      <webElementGuid>3d715a93-73ff-412a-b63b-60c796494332</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;page-container&quot;)/div[@class=&quot;sc-bfdVwy egDjvI&quot;]/div[@class=&quot;sc-FaLkm kcSEUl&quot;]/div[@class=&quot;ant-card ant-card-bordered sc-iMGUdT kynnSF&quot;]/div[@class=&quot;ant-card-body&quot;]/span[@class=&quot;sc-kPpJbQ hrykxW&quot;]/div[@class=&quot;sc-cBaIQL jlxEYs&quot;]/div[@class=&quot;sc-jVCHgA knqiGU&quot;]/div[@class=&quot;sc-hKgILt sc-fsRnyX iJJCRx bcuYfa&quot;]/div[@class=&quot;ant-collapse ant-collapse-icon-position-end ant-collapse-borderless sc-gtTazr bFYtiq&quot;]/div[@class=&quot;ant-collapse-item ant-collapse-item-active sc-dxysmu jHCMiG&quot;]/div[@class=&quot;ant-collapse-content ant-collapse-content-active&quot;]/div[@class=&quot;ant-collapse-content-box&quot;]/div[@class=&quot;sc-krKvcV euxeqF&quot;]/div[@class=&quot;sc-ccvvVe bmwLuT&quot;]/div[@class=&quot;sc-dnyKtg gHrpTr&quot;]/div[1]/div[@class=&quot;sc-gynscz bkTCkS&quot;]/div[@class=&quot;sc-hKgILt sc-gewdXN iJJCRx iGAEoU&quot;]/span[@class=&quot;ant-typography sc-fMQSxl sc-hcIkuZ gQSsiC cWHGUW&quot;]</value>
      <webElementGuid>d6382375-6e2f-4a40-8bd7-d53ff9d18618</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//div[@id='page-container']/div[2]/div[2]/div[3]/div[2]/span/div/div/div[9]/div[2]/div/div[2]/div/div/div[5]/div/div/div[2]/div/span</value>
      <webElementGuid>7f247f13-3402-4386-bd88-ef859682b893</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Choices'])[5]/following::span[3]</value>
      <webElementGuid>bd51e21a-5186-42c8-9382-f575668c599f</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Radio Button'])[2]/following::span[5]</value>
      <webElementGuid>672ad16e-ec32-41ae-a722-8272dfacffde</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='label is missing'])[2]/preceding::span[3]</value>
      <webElementGuid>8831943d-ea07-45b8-a15b-f64d688293c3</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Add More'])[1]/preceding::span[4]</value>
      <webElementGuid>43d8de97-3a6b-4b1c-b489-5acbc52b1a51</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>//*/text()[normalize-space(.)='label is missing']/parent::*</value>
      <webElementGuid>97ef65da-ffbc-4569-a3c0-382de069c693</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//div[5]/div/div/div[2]/div/span</value>
      <webElementGuid>4f0a5013-d3b4-490d-a1cc-8343604ebf7b</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//span[(text() = 'label is missing' or . = 'label is missing')]</value>
      <webElementGuid>0d57e466-5b41-47df-8670-c20feeaec770</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
