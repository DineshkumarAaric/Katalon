<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>select Agent Abby Charles</name>
   <tag></tag>
   <elementGuidId>c629bb65-9612-42e7-bad1-59c3aa52b76c</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>//div[(text() = 'Abby Charles' or . = 'Abby Charles')]</value>
      </entry>
      <entry>
         <key>CSS</key>
         <value>div.ant-select-item-option-content</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <smartLocatorEnabled>false</smartLocatorEnabled>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>div</value>
      <webElementGuid>19f96d03-ea20-4d44-bce3-8d47ddacc69e</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>ant-select-item-option-content</value>
      <webElementGuid>f5035f98-e7af-4af6-9e0d-0e8ad68d9f04</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>Abby Charles</value>
      <webElementGuid>b33d2a5b-7659-4834-9494-e2d972e31df1</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;undefined_parentBlock&quot;)/div[@class=&quot;sc-hKgILt sc-hfstDU kBgJPZ gsItRQ&quot;]/div[@class=&quot;ant-collapse ant-collapse-icon-position-end sc-dXXpDV carFga&quot;]/div[@class=&quot;ant-collapse-item ant-collapse-item-active sc-ctaxOW kguATu&quot;]/div[@class=&quot;ant-collapse-content ant-collapse-content-active&quot;]/div[@class=&quot;ant-collapse-content-box&quot;]/div[@class=&quot;sc-hKgILt kBgJPZ&quot;]/div[@class=&quot;sc-hKgILt sc-ikNbTp kBgJPZ bxYdi&quot;]/div[@class=&quot;sc-hKgILt sc-kJXhso ePffiV fnjwuZ&quot;]/div[@class=&quot;ant-select sc-jZqKz bHKrjD ant-select-focused ant-select-single ant-select-show-arrow ant-select-open ant-select-show-search&quot;]/div[2]/div[1]/div[@class=&quot;ant-select-dropdown ant-select-dropdown-placement-bottomLeft&quot;]/div[1]/div[@class=&quot;rc-virtual-list&quot;]/div[@class=&quot;rc-virtual-list-holder&quot;]/div[1]/div[@class=&quot;rc-virtual-list-holder-inner&quot;]/div[@class=&quot;ant-select-item ant-select-item-option ant-select-item-option-active&quot;]/div[@class=&quot;ant-select-item-option-content&quot;]</value>
      <webElementGuid>fc227c9f-fddc-4e3b-b140-60ca926bd5f6</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//div[@id='undefined_parentBlock']/div/div/div/div[2]/div/div/div/div[2]/div/div[2]/div/div/div/div[2]/div/div/div/div/div</value>
      <webElementGuid>b9285abf-c912-48ef-9654-5fb42c70ea70</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Search and Select User'])[1]/following::div[13]</value>
      <webElementGuid>dfab8f8a-2533-4a11-9afd-d75ee00992b6</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='.'])[1]/following::div[17]</value>
      <webElementGuid>8d0a8c2f-663a-4f84-bb47-642eb70749b5</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Admin Users123'])[1]/preceding::div[1]</value>
      <webElementGuid>0790a43b-6008-4b33-897c-580dd1ac17c3</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Agent MoveApi'])[1]/preceding::div[3]</value>
      <webElementGuid>19d43db0-9e2a-4119-a086-5bdaa295ecc6</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>//*/text()[normalize-space(.)='Abby Charles']/parent::*</value>
      <webElementGuid>4926ebf6-589b-47cd-9ee6-2ee40bebb676</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//div/div/div[2]/div/div[2]/div/div/div/div[2]/div/div/div/div/div</value>
      <webElementGuid>29f4ffba-ae0c-4fa8-b58e-12a1bc99e17f</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//div[(text() = 'Abby Charles' or . = 'Abby Charles')]</value>
      <webElementGuid>55c432cf-cb61-460e-8326-cb1ef46b322d</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
