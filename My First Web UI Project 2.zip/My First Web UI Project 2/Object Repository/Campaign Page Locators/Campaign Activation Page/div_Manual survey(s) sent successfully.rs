<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>div_Manual survey(s) sent successfully</name>
   <tag></tag>
   <elementGuidId>fd7fd77c-f403-4e44-b0fd-01b42e13a71f</elementGuidId>
   <selectorCollection>
      <entry>
         <key>CSS</key>
         <value>div.ant-notification-notice-message</value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>(.//*[normalize-space(text()) and normalize-space(.)='Accessibility Statement'])[1]/following::div[8]</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <smartLocatorEnabled>false</smartLocatorEnabled>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>div</value>
      <webElementGuid>08133a7e-a949-4bfa-aa6e-63e0c2a8ce75</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>ant-notification-notice-message</value>
      <webElementGuid>971a89c0-6662-47e7-a7be-9b242e71b185</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>Manual survey(s) sent successfully</value>
      <webElementGuid>5927e64a-37be-4be8-84f4-75b42a125b54</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>/html[1]/body[@class=&quot;INDlangdirLTR INDpositionLeft INDDesktop INDChrome INDhasDragTooltip&quot;]/div[3]/div[@class=&quot;ant-notification ant-notification-topRight&quot;]/div[1]/div[@class=&quot;ant-notification-notice ant-notification-notice-success ant-notification-notice-closable&quot;]/div[@class=&quot;ant-notification-notice-content&quot;]/div[@class=&quot;ant-notification-notice-with-icon&quot;]/div[@class=&quot;ant-notification-notice-message&quot;]</value>
      <webElementGuid>5f83aabe-8cc7-488a-bcd2-1c65d673d75e</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Accessibility Statement'])[1]/following::div[8]</value>
      <webElementGuid>095431e4-62d7-47ad-bb9c-aa3e25a362f3</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='|'])[1]/following::div[8]</value>
      <webElementGuid>7a4c231b-81d1-4e74-8479-ae27cb0e1662</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>//*/text()[normalize-space(.)='Manual survey(s) sent successfully']/parent::*</value>
      <webElementGuid>7b819f8f-5188-4b08-9ad2-c39fe87bf790</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//div[3]/div/div/div/div/div/div</value>
      <webElementGuid>f4118b6f-7328-433f-8cf7-17116c5b52a8</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//div[(text() = 'Manual survey(s) sent successfully' or . = 'Manual survey(s) sent successfully')]</value>
      <webElementGuid>e28de7c1-f65b-43c2-b19e-11fc98a1567c</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
