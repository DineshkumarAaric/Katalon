<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>div_Likert Scale Question</name>
   <tag></tag>
   <elementGuidId>f58fabd8-8582-432a-9a5b-9e771fea2aa7</elementGuidId>
   <selectorCollection>
      <entry>
         <key>CSS</key>
         <value>div.sc-hKgILt.sc-ktxhKL.iJJCRx.bLLsjP > div.sc-hKgILt.sc-hxczxO.iJJCRx.dNShxu</value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>//div[@id='page-container']/div[2]/div[2]/div[3]/div[2]/span/div/div[2]/div/div[2]/div/div[2]/div[2]/div[2]/div</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <smartLocatorEnabled>false</smartLocatorEnabled>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>div</value>
      <webElementGuid>73ba5f8a-47a1-4475-ac06-8887e02e7261</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>sc-hKgILt sc-hxczxO iJJCRx dNShxu</value>
      <webElementGuid>6262eb10-3060-4ab1-994d-7cace204afa2</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>Likert Scale Question</value>
      <webElementGuid>68e11bda-9f9d-4cb9-b50d-844e906b104c</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;page-container&quot;)/div[@class=&quot;sc-bfdVwy egDjvI&quot;]/div[@class=&quot;sc-FaLkm kcSEUl&quot;]/div[@class=&quot;ant-card ant-card-bordered sc-iMGUdT kynnSF&quot;]/div[@class=&quot;ant-card-body&quot;]/span[@class=&quot;sc-kPpJbQ hrykxW&quot;]/div[@class=&quot;sc-cBaIQL jlxEYs&quot;]/div[@class=&quot;ant-collapse ant-collapse-icon-position-end ant-collapse-borderless sc-fHHSrm bxOZue&quot;]/div[@class=&quot;ant-collapse-item ant-collapse-item-active sc-cNytvn bVyehQ&quot;]/div[@class=&quot;ant-collapse-content ant-collapse-content-active&quot;]/div[@class=&quot;ant-collapse-content-box&quot;]/div[@class=&quot;sc-ceLVMN krvcpf&quot;]/div[@class=&quot;sc-bCBFUB iECNdW&quot;]/div[@class=&quot;sc-hKgILt sc-ktxhKL iJJCRx bLLsjP&quot;]/div[@class=&quot;sc-hKgILt sc-hxczxO iJJCRx dNShxu&quot;]</value>
      <webElementGuid>88a36d95-b88a-4d72-91b3-5169798c949c</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//div[@id='page-container']/div[2]/div[2]/div[3]/div[2]/span/div/div[2]/div/div[2]/div/div[2]/div[2]/div[2]/div</value>
      <webElementGuid>41317f37-8b4b-43af-bcf0-b1145ce46511</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Slider Question'])[2]/following::div[2]</value>
      <webElementGuid>1dfd8aaa-389b-4e07-a9b8-8d4bb9210097</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Rating Scale'])[6]/following::div[4]</value>
      <webElementGuid>94241f2d-cd1a-4ce0-9037-588dae13beae</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Open Ended'])[1]/preceding::div[2]</value>
      <webElementGuid>24cab8a6-c388-49b0-8413-8e6cb5103256</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//div[2]/div/div[2]/div/div[2]/div[2]/div[2]/div</value>
      <webElementGuid>95a869aa-a929-4c18-beb2-21f963cb4e35</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//div[(text() = 'Likert Scale Question' or . = 'Likert Scale Question')]</value>
      <webElementGuid>fe3b6cb3-b0a1-4e3b-ac07-30690a789fe9</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
