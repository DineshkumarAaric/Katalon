<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>span_Total Surveys Sent</name>
   <tag></tag>
   <elementGuidId>1c919af7-dae9-4318-95f8-e2a29c33ed84</elementGuidId>
   <selectorCollection>
      <entry>
         <key>CSS</key>
         <value>span.sc-gtYqZM.gvZieY</value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>//div[@id='campaign_dashboard_metrics_card']/div/span[2]</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <smartLocatorEnabled>false</smartLocatorEnabled>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>span</value>
      <webElementGuid>ed2b002c-b402-45ff-9414-9a90fb15af17</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>sc-gtYqZM gvZieY</value>
      <webElementGuid>415f8dec-6146-4b6c-8e91-7572ce0b3a9a</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>Total Surveys Sent</value>
      <webElementGuid>09fca421-8531-4993-9198-b96598b2984c</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;campaign_dashboard_metrics_card&quot;)/div[@class=&quot;sc-hKgILt sc-cZodPi kBgJPZ juqDMS&quot;]/span[@class=&quot;sc-gtYqZM gvZieY&quot;]</value>
      <webElementGuid>8c7782b5-3f63-4061-af2c-e3a8be64436c</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//div[@id='campaign_dashboard_metrics_card']/div/span[2]</value>
      <webElementGuid>00e19a19-a560-4e6b-b0e1-12905be805fc</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Account Manager'])[3]/following::span[2]</value>
      <webElementGuid>f7389855-ad32-4fd7-87cd-ea6ebbf6ba2f</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Automation AccMngr'])[3]/following::span[2]</value>
      <webElementGuid>a235d656-4516-421e-901e-91795bf4d3f0</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Total Responses'])[1]/preceding::span[2]</value>
      <webElementGuid>051067d3-c9e3-4ba3-841d-daa6bcdf65b4</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Average Completion Rate'])[1]/preceding::span[4]</value>
      <webElementGuid>41ef2599-ea4d-48cb-9a40-4696a3f7fa05</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>//*/text()[normalize-space(.)='Total Surveys Sent']/parent::*</value>
      <webElementGuid>e433f365-137b-4f3a-ac7a-da64ff2360fd</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//div[2]/div/div/span[2]</value>
      <webElementGuid>08b3418a-2b1e-4ac5-93b5-074e77021ffd</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//span[(text() = 'Total Surveys Sent' or . = 'Total Surveys Sent')]</value>
      <webElementGuid>83637a1d-8b7f-43db-ada8-736c868eea60</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
