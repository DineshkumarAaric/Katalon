<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>div_Q4. Drag and Drop an image or  Browse (_d2179f</name>
   <tag></tag>
   <elementGuidId>740b889e-c9ac-4601-b56e-750250ce6726</elementGuidId>
   <selectorCollection>
      <entry>
         <key>CSS</key>
         <value>div.ant-collapse-content.ant-collapse-content-active > div.ant-collapse-content-box > div.sc-krKvcV.euxeqF > div.sc-gKQthM.fUIalg</value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>//div[@id='page-container']/div[2]/div[2]/div[3]/div[2]/span/div/div/div[4]/div[2]/div/div[2]/div/div/div[6]</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <smartLocatorEnabled>false</smartLocatorEnabled>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>div</value>
      <webElementGuid>ebbc747f-8564-4b98-9622-887794db942c</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>sc-gKQthM fUIalg</value>
      <webElementGuid>e7262cbf-77db-4f27-ba85-d919860938e2</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>Q4.  Drag and Drop an image or  Browse (Accepted Files: jpg,png,doc,xlsx,csv)</value>
      <webElementGuid>74190d11-dd62-497f-b5a0-f1bae8c817a8</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;page-container&quot;)/div[@class=&quot;sc-bfdVwy egDjvI&quot;]/div[@class=&quot;sc-FaLkm kcSEUl&quot;]/div[@class=&quot;ant-card ant-card-bordered sc-iMGUdT kynnSF&quot;]/div[@class=&quot;ant-card-body&quot;]/span[@class=&quot;sc-kPpJbQ hrykxW&quot;]/div[@class=&quot;sc-cBaIQL jlxEYs&quot;]/div[@class=&quot;sc-jVCHgA knqiGU&quot;]/div[@class=&quot;sc-hKgILt sc-fsRnyX iJJCRx bcuYfa&quot;]/div[@class=&quot;ant-collapse ant-collapse-icon-position-end ant-collapse-borderless sc-gtTazr bFYtiq&quot;]/div[@class=&quot;ant-collapse-item ant-collapse-item-active sc-dxysmu jHCMiG&quot;]/div[@class=&quot;ant-collapse-content ant-collapse-content-active&quot;]/div[@class=&quot;ant-collapse-content-box&quot;]/div[@class=&quot;sc-krKvcV euxeqF&quot;]/div[@class=&quot;sc-gKQthM fUIalg&quot;]</value>
      <webElementGuid>e2e20918-07bd-45df-ac6c-3380868cf3a2</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//div[@id='page-container']/div[2]/div[2]/div[3]/div[2]/span/div/div/div[4]/div[2]/div/div[2]/div/div/div[6]</value>
      <webElementGuid>92bd443d-d1c8-475b-9ff7-f5e580434d25</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Format Preview'])[3]/following::div[1]</value>
      <webElementGuid>7c6355be-5de6-4dd4-a2a6-943b2c8fcd5f</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='csv'])[3]/following::div[2]</value>
      <webElementGuid>26a62ec3-b5ca-4832-bbb0-e7f0cf49e567</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//div[4]/div[2]/div/div[2]/div/div/div[6]</value>
      <webElementGuid>ba699e0f-d6e6-4d9b-a98a-7095e49ebb8d</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//div[(text() = 'Q4.  Drag and Drop an image or  Browse (Accepted Files: jpg,png,doc,xlsx,csv)' or . = 'Q4.  Drag and Drop an image or  Browse (Accepted Files: jpg,png,doc,xlsx,csv)')]</value>
      <webElementGuid>d0b41721-50a3-4aa3-a171-346feb925e11</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
