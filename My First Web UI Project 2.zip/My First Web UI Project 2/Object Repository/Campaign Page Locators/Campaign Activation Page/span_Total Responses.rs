<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>span_Total Responses</name>
   <tag></tag>
   <elementGuidId>87b240f0-83d9-48d5-9149-ab6683bc0267</elementGuidId>
   <selectorCollection>
      <entry>
         <key>CSS</key>
         <value></value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>//div[@id='campaign_dashboard_metrics_card']/div[2]/span[2]</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <smartLocatorEnabled>false</smartLocatorEnabled>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>span</value>
      <webElementGuid>3dff656d-afa8-48af-aeb1-52befe00d743</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>sc-gtYqZM gvZieY</value>
      <webElementGuid>0ff6ebdd-d1a4-4cc5-959d-94df330a5c3c</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>Total Responses</value>
      <webElementGuid>3a5aa520-e208-4332-9310-7c812be33734</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;campaign_dashboard_metrics_card&quot;)/div[@class=&quot;sc-hKgILt sc-cZodPi kBgJPZ juqDMS&quot;]/span[@class=&quot;sc-gtYqZM gvZieY&quot;]</value>
      <webElementGuid>fa342208-588d-4e0d-b35e-bbac2d40ab5c</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//div[@id='campaign_dashboard_metrics_card']/div[2]/span[2]</value>
      <webElementGuid>62954f48-6eec-44f8-a191-2b6f6a76c3f4</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Total Surveys Sent'])[1]/following::span[2]</value>
      <webElementGuid>1a2a89eb-5798-49ab-af4a-2ae760dba2f1</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Account Manager'])[3]/following::span[4]</value>
      <webElementGuid>3da8a149-3e92-472d-9aec-5d585218f362</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Average Completion Rate'])[1]/preceding::span[2]</value>
      <webElementGuid>f45dfc90-ffb0-4bcb-949e-8cf9c054eb59</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Incomplete Surveys'])[1]/preceding::span[4]</value>
      <webElementGuid>4c713e4c-fbd2-4931-998f-cd85025d4f93</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>//*/text()[normalize-space(.)='Total Responses']/parent::*</value>
      <webElementGuid>dce35356-9823-4f74-a1c5-13ad8fe1a16d</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//div[2]/span[2]</value>
      <webElementGuid>8b33ad9f-794f-46d7-9321-64dbde4ba13f</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//span[(text() = 'Total Responses' or . = 'Total Responses')]</value>
      <webElementGuid>d6a891c9-5b2d-4bbb-adf7-a7a6e2620e58</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
