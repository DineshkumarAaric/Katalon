<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>span_Incomplete Surveys</name>
   <tag></tag>
   <elementGuidId>2c1239a1-f40b-4711-a896-0710025ff4f9</elementGuidId>
   <selectorCollection>
      <entry>
         <key>CSS</key>
         <value></value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>//div[@id='campaign_dashboard_metrics_card']/div[4]/span[2]</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <smartLocatorEnabled>false</smartLocatorEnabled>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>span</value>
      <webElementGuid>40ba6dd5-a756-4e89-b15d-a6f5b2dcd7e6</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>sc-gtYqZM gvZieY</value>
      <webElementGuid>cdce9d3e-e90c-4a6c-ab48-1fc6768b8bcc</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>Incomplete Surveys</value>
      <webElementGuid>2bc9027e-78af-432d-a540-f50723dad26b</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;campaign_dashboard_metrics_card&quot;)/div[@class=&quot;sc-hKgILt sc-cZodPi kBgJPZ juqDMS&quot;]/span[@class=&quot;sc-gtYqZM gvZieY&quot;]</value>
      <webElementGuid>a69cce21-fab5-42c6-984e-c00468eedb3e</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//div[@id='campaign_dashboard_metrics_card']/div[4]/span[2]</value>
      <webElementGuid>4d2b0533-164e-468a-be0e-50120ed82e2b</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Average Completion Rate'])[1]/following::span[2]</value>
      <webElementGuid>112a8930-e934-46d7-9926-960d3930a6c0</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Total Responses'])[1]/following::span[4]</value>
      <webElementGuid>54a796f6-f697-41db-9e2e-bb956b37b99c</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Activity Feeds'])[1]/preceding::span[1]</value>
      <webElementGuid>89910e4f-5a26-48cd-8101-50fb9da93194</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Create New'])[1]/preceding::span[6]</value>
      <webElementGuid>2e3e4b2e-4a68-41fe-8d51-db33d78d358e</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>//*/text()[normalize-space(.)='Incomplete Surveys']/parent::*</value>
      <webElementGuid>300c8fab-16ce-4873-8e9e-bd3624119de4</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//div[4]/span[2]</value>
      <webElementGuid>277c175a-d43d-4e05-be5e-9ae8fd8fb9c2</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//span[(text() = 'Incomplete Surveys' or . = 'Incomplete Surveys')]</value>
      <webElementGuid>427a7975-78ba-4f08-9424-a31473efef53</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
