<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>span_Average Completion Rate</name>
   <tag></tag>
   <elementGuidId>4113b2d7-128a-487b-b507-cd97a7ce5076</elementGuidId>
   <selectorCollection>
      <entry>
         <key>CSS</key>
         <value></value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>//div[@id='campaign_dashboard_metrics_card']/div[3]/span[2]</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <smartLocatorEnabled>false</smartLocatorEnabled>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>span</value>
      <webElementGuid>4a3ff9bb-e171-492d-8e57-dd660e512679</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>sc-gtYqZM gvZieY</value>
      <webElementGuid>11ca0da7-57cd-4581-bfab-706fe28684e7</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>Average Completion Rate</value>
      <webElementGuid>f551a914-ffd5-480a-95f1-35d40ed1b6c4</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;campaign_dashboard_metrics_card&quot;)/div[@class=&quot;sc-hKgILt sc-cZodPi kBgJPZ juqDMS&quot;]/span[@class=&quot;sc-gtYqZM gvZieY&quot;]</value>
      <webElementGuid>ea68e89a-6976-4032-8734-820ab9437348</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//div[@id='campaign_dashboard_metrics_card']/div[3]/span[2]</value>
      <webElementGuid>03481543-c897-4b57-9ebd-c807868d3d21</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Total Responses'])[1]/following::span[2]</value>
      <webElementGuid>b9db990c-2fc8-4194-95d0-0e876dd7a666</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Total Surveys Sent'])[1]/following::span[4]</value>
      <webElementGuid>6a0db285-cc0d-41a2-9c85-ae49be2d7225</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Incomplete Surveys'])[1]/preceding::span[2]</value>
      <webElementGuid>322227bb-1ae4-4037-9a88-773a8e1aa7d3</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Activity Feeds'])[1]/preceding::span[3]</value>
      <webElementGuid>6da633a8-ddcc-4c6e-97a2-a4a1900bb191</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>//*/text()[normalize-space(.)='Average Completion Rate']/parent::*</value>
      <webElementGuid>830db3d7-58b0-43f1-a3d1-28e9c95e2204</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//div[3]/span[2]</value>
      <webElementGuid>7b9df7ff-d856-44ca-aed2-b5ad1c103497</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//span[(text() = 'Average Completion Rate' or . = 'Average Completion Rate')]</value>
      <webElementGuid>b4483af6-7f96-4002-a6ff-642af5b9893c</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
