<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>span_Go to SMS setup</name>
   <tag></tag>
   <elementGuidId>75845297-a8ff-4ec4-866d-464add21f7bc</elementGuidId>
   <selectorCollection>
      <entry>
         <key>CSS</key>
         <value>span.sc-hHUFbR.BxSVb</value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>//div[@id='page-container']/div[2]/div[2]/div[3]/div/div/div/div/div/div/span</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <smartLocatorEnabled>false</smartLocatorEnabled>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>span</value>
      <webElementGuid>f17e588b-7728-4315-b0a0-63ee30ce8d87</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>sc-hHUFbR BxSVb</value>
      <webElementGuid>3c607390-08ac-4aee-866a-99b677a5afce</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>Go to SMS setup</value>
      <webElementGuid>32e82e47-5cd1-4b7c-ab17-baf324ec94a5</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;page-container&quot;)/div[@class=&quot;sc-bfdVwy egDjvI&quot;]/div[@class=&quot;sc-FaLkm kcSEUl&quot;]/div[@class=&quot;ant-card ant-card-bordered sc-iMGUdT kynnSF&quot;]/div[@class=&quot;ant-card-head&quot;]/div[@class=&quot;ant-card-head-wrapper&quot;]/div[@class=&quot;ant-card-head-title&quot;]/div[@class=&quot;sc-hKgILt fMWbrt&quot;]/div[@class=&quot;sc-cjLdud UIFld&quot;]/div[@class=&quot;sc-hKgILt WxKTo&quot;]/span[@class=&quot;sc-hHUFbR BxSVb&quot;]</value>
      <webElementGuid>adc3fbe1-f6d0-4c4b-8c40-aedbc3201ab5</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//div[@id='page-container']/div[2]/div[2]/div[3]/div/div/div/div/div/div/span</value>
      <webElementGuid>fff3675b-5592-47f1-bb26-e8638e70ae6c</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Email Setup'])[2]/following::span[1]</value>
      <webElementGuid>ada179e2-c7b4-4c25-8c62-99c345e0fac2</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Setup Configuration'])[1]/following::span[2]</value>
      <webElementGuid>f2998d17-d17f-43a8-99ad-0c84ce8bcaab</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Campaign Email 1'])[1]/preceding::span[1]</value>
      <webElementGuid>29efd1fb-4a26-457a-b6c1-3d2e7a4e14d7</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Campaign Email 2'])[1]/preceding::span[1]</value>
      <webElementGuid>b8138091-b1b8-4365-8ddd-34a2cba1bb31</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>//*/text()[normalize-space(.)='Go to']/parent::*</value>
      <webElementGuid>f22c5098-d4b6-4e71-a894-507a82a3dd4a</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//div[3]/div/div/div/div/div/div/span</value>
      <webElementGuid>3b296dd4-e5bf-4c3b-8ca1-7409e4ab397f</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//span[(text() = 'Go to SMS setup' or . = 'Go to SMS setup')]</value>
      <webElementGuid>5062028a-1472-4848-966b-79e4d812eb81</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
