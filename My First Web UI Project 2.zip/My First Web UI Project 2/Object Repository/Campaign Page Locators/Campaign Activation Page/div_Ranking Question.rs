<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>div_Ranking Question</name>
   <tag></tag>
   <elementGuidId>fef2c146-8c9c-4397-ac2c-2a104393a890</elementGuidId>
   <selectorCollection>
      <entry>
         <key>IMAGE</key>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>//div[@id='page-container']/div[2]/div[2]/div[3]/div[2]/span/div/div[2]/div/div[2]/div/div[2]/div[2]/div[2]/div[4]</value>
      </entry>
      <entry>
         <key>BASIC</key>
         <value>//*[(text() = 'Ranking Question' or . = 'Ranking Question')]</value>
      </entry>
      <entry>
         <key>CSS</key>
         <value>(.//*[normalize-space(text()) and normalize-space(.)='Image Question'])[1]/preceding::div[2]</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <smartLocatorEnabled>false</smartLocatorEnabled>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>div</value>
      <webElementGuid>3d914a40-9d4c-430c-b10a-caa1300d5a77</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>sc-hKgILt sc-hxczxO iJJCRx dNShxu</value>
      <webElementGuid>d1671098-7604-4959-96fb-c4801ce47bff</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>Ranking Question</value>
      <webElementGuid>f9ef9acf-fea2-44cb-8c79-18a30eee6171</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;page-container&quot;)/div[@class=&quot;sc-bfdVwy egDjvI&quot;]/div[@class=&quot;sc-FaLkm kcSEUl&quot;]/div[@class=&quot;ant-card ant-card-bordered sc-iMGUdT kynnSF&quot;]/div[@class=&quot;ant-card-body&quot;]/span[@class=&quot;sc-kPpJbQ hrykxW&quot;]/div[@class=&quot;sc-cBaIQL jlxEYs&quot;]/div[@class=&quot;ant-collapse ant-collapse-icon-position-end ant-collapse-borderless sc-fHHSrm bxOZue&quot;]/div[@class=&quot;ant-collapse-item ant-collapse-item-active sc-cNytvn bVyehQ&quot;]/div[@class=&quot;ant-collapse-content ant-collapse-content-active&quot;]/div[@class=&quot;ant-collapse-content-box&quot;]/div[@class=&quot;sc-ceLVMN krvcpf&quot;]/div[@class=&quot;sc-bCBFUB iECNdW&quot;]/div[@class=&quot;sc-hKgILt sc-ktxhKL iJJCRx bLLsjP&quot;]/div[@class=&quot;sc-hKgILt sc-hxczxO iJJCRx dNShxu&quot;]</value>
      <webElementGuid>33b331f3-3c78-4ccd-8e18-0a9cb14ca25f</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//div[@id='page-container']/div[2]/div[2]/div[3]/div[2]/span/div/div[2]/div/div[2]/div/div[2]/div[2]/div[2]/div[4]</value>
      <webElementGuid>80e14e25-fbe7-49d8-82ab-ecebe608cb71</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Dropdown'])[3]/following::div[1]</value>
      <webElementGuid>3b7ae2c0-0387-43c0-980a-a60662f7e718</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Open Ended'])[5]/following::div[3]</value>
      <webElementGuid>b59e196f-3101-4216-aef6-b86373a51a2a</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Image Question'])[1]/preceding::div[2]</value>
      <webElementGuid>0b64f40a-26e4-4b3b-acc0-38d2ec408de8</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//div[2]/div[2]/div[2]/div[4]</value>
      <webElementGuid>ddb7f7de-e1b8-4405-b636-7096ec021059</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//div[(text() = 'Ranking Question' or . = 'Ranking Question')]</value>
      <webElementGuid>184f2336-260c-4eb6-add8-653320e7734b</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
