<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>div_Activity Feeds</name>
   <tag></tag>
   <elementGuidId>afae1928-a3e3-4bcc-8961-4de39b3b581f</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>//button[@id='campaign_activity_feed']/div</value>
      </entry>
      <entry>
         <key>CSS</key>
         <value>#campaign_activity_feed > div.sc-hKgILt.ePffiV</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <smartLocatorEnabled>false</smartLocatorEnabled>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>div</value>
      <webElementGuid>015185c7-87e1-4cc4-b177-f9a0c37eaaa3</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>sc-hKgILt ePffiV</value>
      <webElementGuid>7cf7f437-5db1-431f-ab93-14bd4abe5af8</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>Activity Feeds</value>
      <webElementGuid>9759fbea-6088-49d7-88c7-cd90d8a5e4d9</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;campaign_activity_feed&quot;)/div[@class=&quot;sc-hKgILt ePffiV&quot;]</value>
      <webElementGuid>af3a9a36-3f4a-4279-aeb3-a8cb924d8692</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//button[@id='campaign_activity_feed']/div</value>
      <webElementGuid>158746d9-05c4-48c7-a742-43e15db904a8</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Incomplete Surveys'])[1]/following::div[2]</value>
      <webElementGuid>c16862f8-2c52-48c0-aa40-e87c646231f4</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Average Completion Rate'])[1]/following::div[3]</value>
      <webElementGuid>099a8207-eb74-486b-a91c-961c0d971b31</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Create New'])[1]/preceding::div[8]</value>
      <webElementGuid>699fa0db-c203-402d-9304-66b2119a76af</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Campaigns'])[3]/preceding::div[13]</value>
      <webElementGuid>de02bf5c-eba0-492d-836d-f137142af7dc</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>//*/text()[normalize-space(.)='Activity Feeds']/parent::*</value>
      <webElementGuid>f9da632d-a8d4-49e4-beb3-2ff90ac9303b</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//button/div</value>
      <webElementGuid>b06633b5-58d1-49c2-90ec-9f306384dc7d</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//div[(text() = 'Activity Feeds' or . = 'Activity Feeds')]</value>
      <webElementGuid>89d81f4e-8d3c-44d4-9afe-cf02e109ee52</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
