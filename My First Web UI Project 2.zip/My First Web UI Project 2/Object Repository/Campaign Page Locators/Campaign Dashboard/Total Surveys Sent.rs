<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>Total Surveys Sent</name>
   <tag></tag>
   <elementGuidId>60333e8f-ba03-4546-ad6b-31849ed8bdaf</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>//div[@id='campaign_dashboard_metrics_card']/div/span[2]</value>
      </entry>
      <entry>
         <key>CSS</key>
         <value>span.sc-gtYqZM.gvZieY</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <smartLocatorEnabled>false</smartLocatorEnabled>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>span</value>
      <webElementGuid>2fab150f-3a7e-4cfb-8f04-84502e93a165</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>sc-gtYqZM gvZieY</value>
      <webElementGuid>5ebfb2de-042c-41d4-b292-5c542781ba6a</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>Total Surveys Sent</value>
      <webElementGuid>90625d10-a083-49b8-aa1a-b6569d4e1bb8</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;campaign_dashboard_metrics_card&quot;)/div[@class=&quot;sc-hKgILt sc-cZodPi kBgJPZ juqDMS&quot;]/span[@class=&quot;sc-gtYqZM gvZieY&quot;]</value>
      <webElementGuid>53ac9ed3-920a-4b5c-b255-32b2b6ed604f</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//div[@id='campaign_dashboard_metrics_card']/div/span[2]</value>
      <webElementGuid>f9fb3c93-82c7-418a-ab7f-18ab1d525a4a</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Account Manager'])[3]/following::span[2]</value>
      <webElementGuid>8b1e928d-5990-43ea-9376-2ddc2f7e6627</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Automation AccMngr'])[3]/following::span[2]</value>
      <webElementGuid>2e6c2aa7-c372-496c-9fd9-a63f1479282f</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Total Responses'])[1]/preceding::span[2]</value>
      <webElementGuid>b3f23dfc-ba8c-420e-962f-49176bfc7b7c</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Average Completion Rate'])[1]/preceding::span[4]</value>
      <webElementGuid>4d8ff0f8-bd37-4cf3-a99e-8783c97c1922</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>//*/text()[normalize-space(.)='Total Surveys Sent']/parent::*</value>
      <webElementGuid>78c84a0b-8ced-44b0-9b92-9388d61f4f69</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//div[2]/div/div/span[2]</value>
      <webElementGuid>9a0aece9-1fc6-44d8-a418-136a62256cda</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//span[(text() = 'Total Surveys Sent' or . = 'Total Surveys Sent')]</value>
      <webElementGuid>bfc869e6-a31a-4ae8-bbd4-94a3d719cba9</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
