<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>div_Abby Charles</name>
   <tag></tag>
   <elementGuidId>59f5fdbc-e6f5-409b-bed0-57472e604579</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>//*/text()[normalize-space(.)='Abby Charles']/parent::*</value>
      </entry>
      <entry>
         <key>CSS</key>
         <value>div.ant-select-item-option-content</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <smartLocatorEnabled>false</smartLocatorEnabled>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>div</value>
      <webElementGuid>9bf5e5b9-25e0-4fa9-b245-7c078c8ed564</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>ant-select-item-option-content</value>
      <webElementGuid>a598d839-9a9b-4872-9a04-bcaff2424b32</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>Abby Charles</value>
      <webElementGuid>577bb1a0-3329-49b6-b1ef-7d052207db96</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;undefined_parentBlock&quot;)/div[@class=&quot;sc-hKgILt sc-ctaxOW kBgJPZ kguATu&quot;]/div[@class=&quot;ant-collapse ant-collapse-icon-position-end sc-kBbdnT foSJMZ&quot;]/div[@class=&quot;ant-collapse-item ant-collapse-item-active sc-iAOupc gfBPPl&quot;]/div[@class=&quot;ant-collapse-content ant-collapse-content-active&quot;]/div[@class=&quot;ant-collapse-content-box&quot;]/div[@class=&quot;sc-hKgILt kBgJPZ&quot;]/div[@class=&quot;sc-hKgILt sc-gcAEdj kBgJPZ jfFDWq&quot;]/div[@class=&quot;sc-hKgILt sc-iDarWy ePffiV OkjhI&quot;]/div[@class=&quot;ant-select sc-gGwbEE cxqlfq ant-select-focused ant-select-single ant-select-show-arrow ant-select-open ant-select-show-search&quot;]/div[2]/div[1]/div[@class=&quot;ant-select-dropdown ant-select-dropdown-placement-bottomLeft&quot;]/div[1]/div[@class=&quot;rc-virtual-list&quot;]/div[@class=&quot;rc-virtual-list-holder&quot;]/div[1]/div[@class=&quot;rc-virtual-list-holder-inner&quot;]/div[@class=&quot;ant-select-item ant-select-item-option ant-select-item-option-active&quot;]/div[@class=&quot;ant-select-item-option-content&quot;]</value>
      <webElementGuid>d7bea38c-8fba-4140-974f-d383fec3b259</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//div[@id='undefined_parentBlock']/div/div/div/div[2]/div/div/div/div[2]/div/div[2]/div/div/div/div[2]/div/div/div/div/div</value>
      <webElementGuid>44f1e904-71be-4c0f-a5cb-3f25eda49026</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Search and Select User'])[1]/following::div[13]</value>
      <webElementGuid>e6bde4a2-badc-40f2-888a-2a4552b8c8dc</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='.'])[1]/following::div[17]</value>
      <webElementGuid>bb3ddbb7-8d1c-4de2-96ff-b5bf91dadc46</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Admin Users123'])[1]/preceding::div[1]</value>
      <webElementGuid>8a191510-d72d-429b-9c6c-ce3df360b84d</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Agent MoveApi'])[1]/preceding::div[3]</value>
      <webElementGuid>b435ee28-fadf-4b05-aecc-40945bb49f94</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>//*/text()[normalize-space(.)='Abby Charles']/parent::*</value>
      <webElementGuid>966609d7-74cd-446e-b4f9-7123cde5a0fa</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//div[2]/div/div[2]/div/div/div/div[2]/div/div/div/div/div</value>
      <webElementGuid>913fa14a-b252-4226-918d-894637ee910d</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//div[(text() = 'Abby Charles' or . = 'Abby Charles')]</value>
      <webElementGuid>a21ccf1b-0cfd-4f93-8935-22be3f612bc1</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
