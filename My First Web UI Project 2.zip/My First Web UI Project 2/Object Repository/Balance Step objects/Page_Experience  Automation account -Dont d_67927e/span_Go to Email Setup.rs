<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>span_Go to Email Setup</name>
   <tag></tag>
   <elementGuidId>cfc773ad-c4c3-430b-bddd-10d36c8bba22</elementGuidId>
   <selectorCollection>
      <entry>
         <key>CSS</key>
         <value>span.sc-cVCJmT.bKeNxV</value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>(//div[@class='ant-steps-item-container'])[3]</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <smartLocatorEnabled>false</smartLocatorEnabled>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>span</value>
      <webElementGuid>df7c81c4-3f8a-4ae8-b7df-f578c303c29d</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>sc-cVCJmT bKeNxV</value>
      <webElementGuid>007e881d-6eec-4884-884b-08ea3467eb12</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>Go to Email Setup</value>
      <webElementGuid>2d3bb25b-0fc2-4f40-b713-a0d3f770b28e</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;page-container&quot;)/div[@class=&quot;sc-fLrwSF juEMmK&quot;]/div[@class=&quot;sc-FaLkm kcSEUl&quot;]/div[@class=&quot;ant-card ant-card-bordered sc-kPpJbQ cibICl&quot;]/div[@class=&quot;ant-card-head&quot;]/div[@class=&quot;ant-card-head-wrapper&quot;]/div[@class=&quot;ant-card-head-title&quot;]/div[@class=&quot;sc-hKgILt fMWbrt&quot;]/div[@class=&quot;sc-cjLdud UIFld&quot;]/div[@class=&quot;sc-hKgILt WxKTo&quot;]/span[@class=&quot;sc-cVCJmT bKeNxV&quot;]</value>
      <webElementGuid>9dbf02c5-5bb2-4713-a1c8-4f7e00983e61</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//div[@id='page-container']/div[2]/div[2]/div[3]/div/div/div/div/div/div/span</value>
      <webElementGuid>664ed5ac-728d-4711-bbb7-605b94a4ee9f</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Secondary Workflow'])[2]/following::span[1]</value>
      <webElementGuid>ee9a9145-b257-4cb2-bc86-94c4a15e113c</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Setup Configuration'])[1]/following::span[2]</value>
      <webElementGuid>ec064fca-2100-4c72-a154-25c20373768f</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Great'])[1]/preceding::span[1]</value>
      <webElementGuid>6fa7534a-94bc-41aa-bdef-76645dd534f9</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>//*/text()[normalize-space(.)='Go to']/parent::*</value>
      <webElementGuid>038fbbff-87cf-4389-929c-49d24c82eda8</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//div[3]/div/div/div/div/div/div/span</value>
      <webElementGuid>bdaa9a3c-4bb4-480f-8687-358b0ae78f7c</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//span[(text() = 'Go to Email Setup' or . = 'Go to Email Setup')]</value>
      <webElementGuid>a979dc67-01b7-4cbc-939b-5201a27e430e</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
