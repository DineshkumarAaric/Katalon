<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>div_Survey Completed- Email Version 2</name>
   <tag></tag>
   <elementGuidId>4ad5c385-a103-44b4-bb45-ac6661004ee7</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>//div[@id='email_setup_surveyCompletedUnpleasant']/div</value>
      </entry>
      <entry>
         <key>CSS</key>
         <value>#email_setup_surveyCompletedUnpleasant > div.sc-hKgILt.sc-droTyt.cbnLyR.gmnaTQ</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <smartLocatorEnabled>false</smartLocatorEnabled>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>div</value>
      <webElementGuid>f0651271-edd0-45c3-b0b8-de25ab2ab0a6</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>sc-hKgILt sc-droTyt cbnLyR gmnaTQ</value>
      <webElementGuid>091624e6-7ea8-40eb-8e6f-ba72214d1096</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>Survey Completed- Email Version 2 </value>
      <webElementGuid>d58beb09-765c-47c8-adc6-62a4bcfe2ddc</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;email_setup_surveyCompletedUnpleasant&quot;)/div[@class=&quot;sc-hKgILt sc-droTyt cbnLyR gmnaTQ&quot;]</value>
      <webElementGuid>dedbdb4e-21a0-4092-8a94-283eb1f9ac80</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//div[@id='email_setup_surveyCompletedUnpleasant']/div</value>
      <webElementGuid>1bffd230-01f3-43b2-beaa-5ebb25b5e06c</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='- Email Version 1'])[1]/following::div[5]</value>
      <webElementGuid>352d932a-5135-41ed-9a95-d547c8a38341</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Survey Completed'])[1]/following::div[6]</value>
      <webElementGuid>689fc03c-e19b-4e50-8828-0c92337d4041</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//span/div/div/div[4]/div/div</value>
      <webElementGuid>196cdb68-73c8-4ef1-abfb-473f6f2d3638</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//div[(text() = 'Survey Completed- Email Version 2 ' or . = 'Survey Completed- Email Version 2 ')]</value>
      <webElementGuid>5f0ff139-289b-491b-938f-4de7f544748e</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
