<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>span_Go to Setup Configuration</name>
   <tag></tag>
   <elementGuidId>c7173ebf-cdd1-48c9-92c1-cf8b9810288b</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>//div[@id='page-container']/div[2]/div[2]/div[3]/div/div/div/div/div/div/span</value>
      </entry>
      <entry>
         <key>CSS</key>
         <value>span.sc-cVCJmT.bKeNxV</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <smartLocatorEnabled>false</smartLocatorEnabled>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>span</value>
      <webElementGuid>7f263b7e-ebaa-4c7e-b65a-31e2f56c5f92</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>sc-cVCJmT bKeNxV</value>
      <webElementGuid>6e71a323-953d-46de-970c-ed0c0881061e</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>Go to Setup Configuration</value>
      <webElementGuid>7ffc7bf9-fe3b-4b25-a318-71091016e7ac</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;page-container&quot;)/div[@class=&quot;sc-fLrwSF juEMmK&quot;]/div[@class=&quot;sc-FaLkm kcSEUl&quot;]/div[@class=&quot;ant-card ant-card-bordered sc-kPpJbQ eSFqfh&quot;]/div[@class=&quot;ant-card-head&quot;]/div[@class=&quot;ant-card-head-wrapper&quot;]/div[@class=&quot;ant-card-head-title&quot;]/div[@class=&quot;sc-hKgILt fMWbrt&quot;]/div[@class=&quot;sc-cjLdud UIFld&quot;]/div[@class=&quot;sc-hKgILt WxKTo&quot;]/span[@class=&quot;sc-cVCJmT bKeNxV&quot;]</value>
      <webElementGuid>f45573e4-cbfc-42db-9976-760a9777d67c</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//div[@id='page-container']/div[2]/div[2]/div[3]/div/div/div/div/div/div/span</value>
      <webElementGuid>781c96c0-8dca-4671-bead-f9b1198978da</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='SMS setup'])[2]/following::span[1]</value>
      <webElementGuid>92f1cea5-be92-4c62-ad2e-669f6f4bc8b1</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Setup Configuration'])[1]/following::span[2]</value>
      <webElementGuid>88ef350f-e7ab-4b44-89bf-100efa079458</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Initial Survey Request'])[1]/preceding::span[1]</value>
      <webElementGuid>389b5238-c3ca-42d1-8a8c-c6d7d9123ae0</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Survey Reminder'])[1]/preceding::span[1]</value>
      <webElementGuid>f99112d9-c9dd-4523-8ff9-025aa669984e</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>//*/text()[normalize-space(.)='Go to']/parent::*</value>
      <webElementGuid>412afa1c-02a4-448a-ad51-2e5f672f199a</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//div[3]/div/div/div/div/div/div/span</value>
      <webElementGuid>2a887001-d62e-4af4-8e42-9a982b8120ef</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//span[(text() = 'Go to Setup Configuration' or . = 'Go to Setup Configuration')]</value>
      <webElementGuid>b08c5478-844e-4976-b893-849aff312d4b</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
