<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>div_Advance Settings</name>
   <tag></tag>
   <elementGuidId>1440e0d2-ab3a-413b-8321-83ad1677d30a</elementGuidId>
   <selectorCollection>
      <entry>
         <key>CSS</key>
         <value>#campaign_settings_advance_settings > div.sc-hKgILt.sc-gVyftv.cbnLyR.ceicCY > div > div.sc-hKgILt.ePffiV</value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>//div[@id='campaign_settings_advance_settings']/div/div/div</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <smartLocatorEnabled>false</smartLocatorEnabled>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>div</value>
      <webElementGuid>2ce65858-ed2e-4baf-8493-c83e0f4f1090</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>sc-hKgILt ePffiV</value>
      <webElementGuid>95f87987-1e09-4003-b74e-ebc6a60f2154</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>Advance Settings</value>
      <webElementGuid>11162c47-bf35-4e93-a00c-86593200d63d</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;campaign_settings_advance_settings&quot;)/div[@class=&quot;sc-hKgILt sc-gVyftv cbnLyR ceicCY&quot;]/div[1]/div[@class=&quot;sc-hKgILt ePffiV&quot;]</value>
      <webElementGuid>3e1fb148-8c82-4cfc-aa7b-aa397188ecdc</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//div[@id='campaign_settings_advance_settings']/div/div/div</value>
      <webElementGuid>01afa405-2235-4ae2-a62e-4186de2d9162</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Configure Email Alerts And Notifications'])[1]/following::div[5]</value>
      <webElementGuid>f7a36fd3-0e07-4605-b740-677480e1cdd4</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Social Share Settings'])[1]/following::div[10]</value>
      <webElementGuid>da1ce8af-6b09-4e49-8aa2-aed6bfe1cd45</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Activate'])[1]/preceding::div[1]</value>
      <webElementGuid>22a0fa93-64cd-4748-87d5-92f7d0897cb7</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='General Settings'])[2]/preceding::div[5]</value>
      <webElementGuid>51f7ed26-03c7-4d4e-b271-04be100fc947</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>//*/text()[normalize-space(.)='Advance Settings']/parent::*</value>
      <webElementGuid>27d08ef2-9a75-45c4-b1a8-c7f3383889ef</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//div[2]/div[6]/div/div/div/div</value>
      <webElementGuid>c9cb27b4-a2e4-4b0b-8f7a-ccfd25608d07</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//div[(text() = 'Advance Settings' or . = 'Advance Settings')]</value>
      <webElementGuid>233f8f73-9fb7-4c67-a72c-f1d1f27bc677</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
