<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>div_Greater than</name>
   <tag></tag>
   <elementGuidId>6db1f175-9828-45cc-93f1-b3bac3f4ad45</elementGuidId>
   <selectorCollection>
      <entry>
         <key>CSS</key>
         <value>div.ant-select-item.ant-select-item-option.ant-select-item-option-active > div.ant-select-item-option-content</value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>//div[@id='page-container']/div[2]/div[2]/div[2]/div[6]/div[7]/div[4]/div/div/div/div[3]/div/div[2]/div/div/div/div[2]/div/div/div/div[4]/div</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <smartLocatorEnabled>false</smartLocatorEnabled>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>div</value>
      <webElementGuid>42bba660-b755-4cbe-9aa6-bc18058e86ae</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>ant-select-item-option-content</value>
      <webElementGuid>c06bb6c3-4c93-420a-967f-2385d6e31198</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>Greater than</value>
      <webElementGuid>5feea565-3c58-4d10-9230-0ac9d735dd19</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;page-container&quot;)/div[@class=&quot;sc-bfdVwy egDjvI&quot;]/div[@class=&quot;sc-ymLtz dCMMLu&quot;]/div[@class=&quot;sc-ffKpny irZldw&quot;]/div[@class=&quot;sc-gxIghy lluILA&quot;]/div[@class=&quot;sc-gZqxSl cHPrzL&quot;]/div[@class=&quot;sc-hKgILt sc-eUOKPW kBgJPZ vhdKD&quot;]/div[@class=&quot;sc-hKgILt sc-hKKhph kBgJPZ fniuSM&quot;]/div[@class=&quot;sc-hKgILt kBgJPZ&quot;]/div[@class=&quot;sc-hKgILt sc-hKKhph sc-jZjeDE ePffiV fniuSM ldkiaq&quot;]/div[@class=&quot;sc-hKgILt sc-clozcV ePffiV bgbBTn&quot;]/div[@class=&quot;ant-select sc-HHjJA sJCZZ ant-select-focused ant-select-single ant-select-show-arrow ant-select-open&quot;]/div[2]/div[1]/div[@class=&quot;ant-select-dropdown ant-select-dropdown-placement-bottomLeft&quot;]/div[1]/div[@class=&quot;rc-virtual-list&quot;]/div[@class=&quot;rc-virtual-list-holder&quot;]/div[1]/div[@class=&quot;rc-virtual-list-holder-inner&quot;]/div[@class=&quot;ant-select-item ant-select-item-option ant-select-item-option-active&quot;]/div[@class=&quot;ant-select-item-option-content&quot;]</value>
      <webElementGuid>a06b13d9-ed2d-4707-bfdb-18ee93bbb8e7</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//div[@id='page-container']/div[2]/div[2]/div[2]/div[6]/div[7]/div[4]/div/div/div/div[3]/div/div[2]/div/div/div/div[2]/div/div/div/div[4]/div</value>
      <webElementGuid>a1406379-5184-4c05-9aeb-7686a38ab269</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Not equal to'])[1]/following::div[2]</value>
      <webElementGuid>d4efe4a6-c9ce-40b6-8cc9-a8ef7a915546</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Equal to'])[1]/following::div[4]</value>
      <webElementGuid>407c94b4-17de-49d3-8d09-46149c00656f</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Score'])[3]/preceding::div[2]</value>
      <webElementGuid>4a6e97c8-9b87-46a7-801f-ed218598f3a4</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Add Condition'])[1]/preceding::div[6]</value>
      <webElementGuid>52104431-e796-4645-ad11-8b559f0f5ff6</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>//*/text()[normalize-space(.)='Greater than']/parent::*</value>
      <webElementGuid>53f1f30e-3912-4ea8-b8bd-a89376977eac</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//div/div[2]/div/div/div/div[2]/div/div/div/div[4]/div</value>
      <webElementGuid>6dd4f1b9-1faf-406e-a0e2-3be9ef9bbc9c</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//div[(text() = 'Greater than' or . = 'Greater than')]</value>
      <webElementGuid>b84df7c8-07ad-4574-b674-ed239a875f27</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
