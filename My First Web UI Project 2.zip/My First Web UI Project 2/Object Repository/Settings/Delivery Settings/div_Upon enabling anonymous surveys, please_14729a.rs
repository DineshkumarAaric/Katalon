<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>div_Upon enabling anonymous surveys, please_14729a</name>
   <tag></tag>
   <elementGuidId>b85d380c-6800-4f7c-b148-2711956b160a</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>(.//*[normalize-space(text()) and normalize-space(.)='Anonymous Survey'])[1]/following::div[2]</value>
      </entry>
      <entry>
         <key>CSS</key>
         <value>div.sc-foGXJH.jmdevw</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <smartLocatorEnabled>false</smartLocatorEnabled>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>div</value>
      <webElementGuid>cb6481de-954d-4e83-a832-1a779fb5e94c</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>sc-foGXJH jmdevw</value>
      <webElementGuid>aae61530-74eb-42a1-b79a-52fbbadb30ce</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>Upon enabling anonymous surveys, please update the disclaimer for the following email setups - </value>
      <webElementGuid>e8febb74-8f38-4260-8b8a-52d1be1e8c12</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>/html[1]/body[@class=&quot;INDlangdirLTR INDpositionLeft INDDesktop INDChrome INDhasDragTooltip&quot;]/div[6]/div[@class=&quot;ant-drawer ant-drawer-right sc-jcRDWI cesdZl ant-drawer-open&quot;]/div[@class=&quot;ant-drawer-content-wrapper&quot;]/div[@class=&quot;ant-drawer-content&quot;]/div[@class=&quot;ant-drawer-wrapper-body&quot;]/div[@class=&quot;ant-drawer-body&quot;]/div[@class=&quot;sc-foGXJH jmdevw&quot;]</value>
      <webElementGuid>48284849-5a33-4e1b-9fe9-7557acd3df6c</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Anonymous Survey'])[1]/following::div[2]</value>
      <webElementGuid>815f6727-25ce-493c-860d-71f10dae58eb</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Logout'])[1]/following::div[18]</value>
      <webElementGuid>ed28dae0-d4db-4388-b557-9a8a7c106a6c</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>//*/text()[normalize-space(.)='Upon enabling anonymous surveys, please update the disclaimer for the following email setups -']/parent::*</value>
      <webElementGuid>a6280318-3ec6-43dd-9499-2bdca1195a8f</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//div[6]/div/div[3]/div/div/div[2]/div</value>
      <webElementGuid>6a4a69f2-e4f5-47e6-8b7f-e7b75cd78cf5</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//div[(text() = 'Upon enabling anonymous surveys, please update the disclaimer for the following email setups - ' or . = 'Upon enabling anonymous surveys, please update the disclaimer for the following email setups - ')]</value>
      <webElementGuid>72e0db02-bebc-4fdf-ae13-0fc8c51e409c</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
