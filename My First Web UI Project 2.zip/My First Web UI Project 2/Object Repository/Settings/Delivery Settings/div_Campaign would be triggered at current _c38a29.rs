<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>div_Campaign would be triggered at current _c38a29</name>
   <tag></tag>
   <elementGuidId>75c78081-b3cc-4ae9-ac5a-e48da3130e73</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>//div[@id='page-container']/div[2]/div[2]/div[2]/div[3]/div/div/div[4]/div[2]/div[2]/div</value>
      </entry>
      <entry>
         <key>CSS</key>
         <value>div.sc-irsDuJ.kJkbfz > div.sc-hKgILt.sc-hmHSon.ePffiV.bIETwy > div.sc-dUAkSA.ioGJTW</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <smartLocatorEnabled>false</smartLocatorEnabled>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>div</value>
      <webElementGuid>e70b722f-75f4-48dd-b2e2-35f781ee5caf</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>color</name>
      <type>Main</type>
      <value>#185998</value>
      <webElementGuid>a8ded557-d631-493d-980f-fac3c77ded1f</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>sc-dUAkSA ioGJTW</value>
      <webElementGuid>9464f8e8-666f-497f-acf2-44a272f9bd43</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>Campaign would be triggered at current date and current time to all recipients in the target list.</value>
      <webElementGuid>76b2a03c-db1b-46bf-a19e-04de7f7ad348</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;page-container&quot;)/div[@class=&quot;sc-fLrwSF juEMmK&quot;]/div[@class=&quot;sc-ffKpny irZldw&quot;]/div[@class=&quot;sc-jdBJRc cHXmmP&quot;]/div[@class=&quot;sc-kWznkk bEvXEz&quot;]/div[@class=&quot;sc-hKgILt sc-iQipoI kBgJPZ NuVRt&quot;]/div[@class=&quot;sc-hKgILt sc-iQipoI kBgJPZ ONuFB&quot;]/div[@class=&quot;sc-eVemaH goTzKm&quot;]/div[@class=&quot;sc-irsDuJ kJkbfz&quot;]/div[@class=&quot;sc-hKgILt sc-hmHSon ePffiV bIETwy&quot;]/div[@class=&quot;sc-dUAkSA ioGJTW&quot;]</value>
      <webElementGuid>fb18faab-c3d4-4ec1-b594-5691990834cb</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//div[@id='page-container']/div[2]/div[2]/div[2]/div[3]/div/div/div[4]/div[2]/div[2]/div</value>
      <webElementGuid>c17a17b2-9e93-4e4f-905e-50874112addd</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Yes'])[1]/following::div[2]</value>
      <webElementGuid>18d913fb-b5d2-4bac-9a26-0c62e6196682</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Send in bulk'])[1]/following::div[4]</value>
      <webElementGuid>4edf1329-4c0c-4230-8803-73612b9a9700</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Send in batches'])[1]/preceding::div[1]</value>
      <webElementGuid>7f18985e-b39d-4841-98fe-7afce07c2071</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='No'])[1]/preceding::div[4]</value>
      <webElementGuid>4284f5d6-fca9-4a61-afcc-2ffc96167b49</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>//*/text()[normalize-space(.)='Campaign would be triggered at current date and current time to all recipients in the target list.']/parent::*</value>
      <webElementGuid>1941f19a-c391-4635-b69e-78b2b21c0e14</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//div[3]/div/div/div[4]/div[2]/div[2]/div</value>
      <webElementGuid>deb4f2e7-b102-425a-9799-6a6353e35f1c</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//div[(text() = 'Campaign would be triggered at current date and current time to all recipients in the target list.' or . = 'Campaign would be triggered at current date and current time to all recipients in the target list.')]</value>
      <webElementGuid>ce9490f6-1b8f-432d-afdd-ffa9c92aa209</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
