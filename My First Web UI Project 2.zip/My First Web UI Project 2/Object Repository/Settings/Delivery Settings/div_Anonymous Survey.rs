<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>div_Anonymous Survey</name>
   <tag></tag>
   <elementGuidId>ba8805d2-54e4-4003-8ec2-22c093d53e9f</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>//div[text()='Anonymous Survey']</value>
      </entry>
      <entry>
         <key>CSS</key>
         <value>div.sc-IbLQn.dlbEXI</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <smartLocatorEnabled>false</smartLocatorEnabled>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>div</value>
      <webElementGuid>338bb046-3b70-4a75-9e59-2e2542a6d2ef</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>sc-IbLQn dlbEXI</value>
      <webElementGuid>4d73b72f-c73f-4af2-aa4f-3e8c3a539445</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>Anonymous Survey</value>
      <webElementGuid>b5f03c17-69d0-452c-9ca4-d07be4107deb</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>/html[1]/body[@class=&quot;INDlangdirLTR INDpositionLeft INDDesktop INDChrome INDhasDragTooltip&quot;]/div[6]/div[@class=&quot;ant-drawer ant-drawer-right sc-jcRDWI cesdZl ant-drawer-open&quot;]/div[@class=&quot;ant-drawer-content-wrapper&quot;]/div[@class=&quot;ant-drawer-content&quot;]/div[@class=&quot;ant-drawer-wrapper-body&quot;]/div[@class=&quot;ant-drawer-header&quot;]/div[@class=&quot;ant-drawer-header-title&quot;]/div[@class=&quot;ant-drawer-title&quot;]/div[@class=&quot;sc-IbLQn dlbEXI&quot;]</value>
      <webElementGuid>7479d85c-7d57-4740-a6bc-69f35e2a2dae</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Logout'])[1]/following::div[16]</value>
      <webElementGuid>e83b638a-ce96-4354-847e-3b984a5fd41a</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Change Password'])[1]/following::div[16]</value>
      <webElementGuid>396eeb1e-38a3-444f-9b5e-adc61d771f89</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Upon enabling anonymous surveys, please update the disclaimer for the following email setups -'])[1]/preceding::div[1]</value>
      <webElementGuid>6a3a072d-c3e5-426c-853d-db23a8072a2d</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>//*/text()[normalize-space(.)='Anonymous Survey']/parent::*</value>
      <webElementGuid>2a538da4-066c-4ed3-9041-9460c772e39f</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//div/div[3]/div/div/div/div/div/div</value>
      <webElementGuid>95fdd966-ca78-4e0d-a2a6-aa70ad094e04</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//div[(text() = 'Anonymous Survey' or . = 'Anonymous Survey')]</value>
      <webElementGuid>1f7a46d0-7b01-462f-b9a1-d1b835d23fa5</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
