<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>div_Edit  Activate</name>
   <tag></tag>
   <elementGuidId>32a0d510-ce0e-4766-a014-048909a1ef26</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>//div[@id='102094']/div/div/div[9]/div[2]</value>
      </entry>
      <entry>
         <key>CSS</key>
         <value>div.sc-hKgILt.kBgJPZ > div.sc-hKgILt.cbnLyR</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <smartLocatorEnabled>false</smartLocatorEnabled>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>div</value>
      <webElementGuid>0a65951b-fd01-42bf-81f7-583f1647f420</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>sc-hKgILt cbnLyR</value>
      <webElementGuid>1e5b4d9d-1ff8-42a2-b8d7-774beb7759d5</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>Edit &amp; Activate</value>
      <webElementGuid>35d87c23-1615-4265-ad2d-5f0ca3cdf6df</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;102094&quot;)/div[@class=&quot;sc-dhqaCv dcHFLI&quot;]/div[@class=&quot;sc-hKgILt sc-gXfysM bSgVqp hwFLOa&quot;]/div[@class=&quot;sc-hKgILt kBgJPZ&quot;]/div[@class=&quot;sc-hKgILt cbnLyR&quot;]</value>
      <webElementGuid>7caa7cf7-4203-460e-8b7c-c023e23714cb</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//div[@id='102094']/div/div/div[9]/div[2]</value>
      <webElementGuid>0eb42ad5-471a-4858-b174-f50791730858</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Blank Template 123'])[1]/preceding::div[1]</value>
      <webElementGuid>c9eba40e-fa68-41f0-bbd6-2330036b5f18</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//div[9]/div[2]</value>
      <webElementGuid>80bc5412-037e-4f52-b8d4-0a509192bca1</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//div[(text() = 'Edit &amp; Activate' or . = 'Edit &amp; Activate')]</value>
      <webElementGuid>cc1a7cb8-0523-4d20-b06e-63d64f43c29c</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
