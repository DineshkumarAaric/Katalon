<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>div_Add Photo_1_2</name>
   <tag></tag>
   <elementGuidId>2994e0ff-1acd-45d2-a16c-21aaa84e7091</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>//div[@id='upload_option_0']/div</value>
      </entry>
      <entry>
         <key>CSS</key>
         <value>#upload_option_0 > div</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <smartLocatorEnabled>false</smartLocatorEnabled>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>div</value>
      <webElementGuid>be261a45-9b24-4483-bc6a-81c18f371140</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>Add Photo</value>
      <webElementGuid>d87a4a8d-cd07-40e2-9ee6-6232fd3bc85d</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;upload_option_0&quot;)/div[1]</value>
      <webElementGuid>d38df417-f603-4e84-ac09-8d27d2d59a1f</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//div[@id='upload_option_0']/div</value>
      <webElementGuid>985c4d23-f9b7-4ff3-83aa-d364fe7623c9</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Save'])[1]/following::div[16]</value>
      <webElementGuid>eeb9bc11-b3f5-4d9f-a915-a792c71e1960</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Cancel'])[1]/following::div[18]</value>
      <webElementGuid>f83adc8c-e8b7-46e6-b141-858d767baa0d</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='A'])[4]/preceding::div[3]</value>
      <webElementGuid>5f80de43-ca63-4cf7-b97b-d43d3d6db0ea</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Publish Name'])[1]/preceding::div[9]</value>
      <webElementGuid>0b4129cf-e889-4592-ad17-f8cf7d0fec2d</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>//*/text()[normalize-space(.)='Add Photo']/parent::*</value>
      <webElementGuid>4d22b47f-cd74-49ba-8259-e09ed2639fb1</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//div[3]/div/div/div/div/div/div/div[2]/div/div/div</value>
      <webElementGuid>d71894ed-c8a2-45ab-b6ca-73bcce87f3d9</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//div[(text() = 'Add Photo' or . = 'Add Photo')]</value>
      <webElementGuid>7624b326-eab8-4501-829f-187adc941512</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
