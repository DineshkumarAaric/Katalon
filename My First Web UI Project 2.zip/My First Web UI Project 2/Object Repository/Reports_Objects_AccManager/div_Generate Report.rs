<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>div_Generate Report</name>
   <tag></tag>
   <elementGuidId>0e3da61a-7984-4a96-90f7-df5580370ec5</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>(.//*[normalize-space(text()) and normalize-space(.)='Accessibility Statement'])[1]/following::div[17]</value>
      </entry>
      <entry>
         <key>CSS</key>
         <value>div.sc-cGHBHO.bHBDVl</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <smartLocatorEnabled>false</smartLocatorEnabled>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>div</value>
      <webElementGuid>c72858a3-baee-4ceb-99ea-ae17ebdaf917</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>sc-cGHBHO bHBDVl</value>
      <webElementGuid>28bb6b20-bab5-4786-a443-403ef210e154</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>Generate Report.</value>
      <webElementGuid>ef768d5c-2c30-40bf-a78d-3cc2145b4749</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>/html[1]/body[@class=&quot;INDlangdirLTR INDpositionLeft INDDesktop INDChrome INDhasDragTooltip&quot;]/div[5]/div[@class=&quot;ant-notification ant-notification-topRight&quot;]/div[1]/div[@class=&quot;ant-notification-notice ant-notification-notice-closable&quot;]/div[@class=&quot;ant-notification-notice-content&quot;]/div[@class=&quot;ant-notification-notice-with-icon&quot;]/div[@class=&quot;ant-notification-notice-message&quot;]/div[@class=&quot;sc-cGHBHO bHBDVl&quot;]</value>
      <webElementGuid>2d096797-4a1b-4b9b-90d3-53549d24bbb1</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Accessibility Statement'])[1]/following::div[17]</value>
      <webElementGuid>f870375a-d512-4bc0-85d2-c8cd30df3d6b</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='|'])[1]/following::div[17]</value>
      <webElementGuid>f7a12784-97b2-433c-892a-497f742adb35</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Report can be downloaded once it is generated.'])[1]/preceding::div[1]</value>
      <webElementGuid>c65b6f82-7bd0-4188-aa9a-c691e3dee492</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Automation Agent1'])[2]/preceding::div[4]</value>
      <webElementGuid>5589f015-060b-4fce-83ce-3bad2b1038a6</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>//*/text()[normalize-space(.)='Generate Report.']/parent::*</value>
      <webElementGuid>71862abb-8a93-41f0-9c2c-df633c6c30a2</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//div[5]/div/div/div/div/div/div/div</value>
      <webElementGuid>95cbd2cb-a5e1-47b2-9b8c-7ee18e8ba2ea</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//div[(text() = 'Generate Report.' or . = 'Generate Report.')]</value>
      <webElementGuid>242e946b-be97-413b-936a-3f35f999b5b8</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
