<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>div_Export Report</name>
   <tag></tag>
   <elementGuidId>3f2c08e2-4b39-4dd0-b527-ef9e06ac6545</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>//button[@id='reports_reportCard_reportButton_submitButton']/div</value>
      </entry>
      <entry>
         <key>CSS</key>
         <value>div.sc-hKgILt.gKEjrB</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <smartLocatorEnabled>false</smartLocatorEnabled>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>div</value>
      <webElementGuid>993c9f30-773b-41b1-b3e3-0b46aa927a28</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>sc-hKgILt gKEjrB</value>
      <webElementGuid>fe641c6d-d32d-47e3-8e67-298bf9a51e10</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value> Export Report </value>
      <webElementGuid>a279ed2f-bb89-4b3e-9f15-e78c7b2a2fde</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;reports_reportCard_reportButton_submitButton&quot;)/div[@class=&quot;sc-hKgILt gKEjrB&quot;]</value>
      <webElementGuid>82fba71c-bfe6-4323-beee-6ac32c8d98ba</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//button[@id='reports_reportCard_reportButton_submitButton']/div</value>
      <webElementGuid>3e230ea4-0b69-4552-8226-6c44780065ba</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Download'])[1]/following::div[2]</value>
      <webElementGuid>9aeb7421-5f62-4b8d-ae70-62026ed0fb0c</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Action'])[1]/following::div[7]</value>
      <webElementGuid>caa85c73-d517-495b-940e-e99c41020651</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Activity Feeds'])[1]/preceding::div[1]</value>
      <webElementGuid>b9b388d7-ac2d-442e-970c-14917668cf58</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='View All'])[1]/preceding::div[3]</value>
      <webElementGuid>70f3f0e0-f93f-4d98-9c9a-219793994dfd</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//button/div</value>
      <webElementGuid>dec35653-d472-47ee-8590-e861e034bbc3</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//div[(text() = ' Export Report ' or . = ' Export Report ')]</value>
      <webElementGuid>98615cf9-a9d6-401a-a185-e29b714255e7</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
