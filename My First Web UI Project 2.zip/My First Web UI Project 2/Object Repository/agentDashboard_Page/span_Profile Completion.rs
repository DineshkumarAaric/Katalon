<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>span_Profile Completion</name>
   <tag></tag>
   <elementGuidId>82625f32-07d6-4b84-a55c-d2c118f58730</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>//div[@id='overview_card_tooltip3']/div/span</value>
      </entry>
      <entry>
         <key>CSS</key>
         <value>#overview_card_tooltip3 > div.sc-hKgILt.sc-jyHcoZ.eObgQR.crLLsl > span</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <smartLocatorEnabled>false</smartLocatorEnabled>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>span</value>
      <webElementGuid>323f698e-00ca-4abd-a50a-454312c9ab7c</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>Profile Completion</value>
      <webElementGuid>92d7caf7-2038-4ca4-9453-20143bfa1e1d</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;overview_card_tooltip3&quot;)/div[@class=&quot;sc-hKgILt sc-jyHcoZ eObgQR crLLsl&quot;]/span[1]</value>
      <webElementGuid>b7f66022-42cf-4999-af5e-091cb530f402</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//div[@id='overview_card_tooltip3']/div/span</value>
      <webElementGuid>bec84a4f-9d3f-41b5-9757-a23fc45befd8</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='points'])[1]/following::span[3]</value>
      <webElementGuid>7ad4ceb5-577f-4926-b409-eaa9ccedfee5</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='of'])[2]/following::span[5]</value>
      <webElementGuid>f2e0824b-3bc5-446c-a8c5-f4984a9e46b1</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='incomplete items'])[1]/preceding::span[3]</value>
      <webElementGuid>1250b866-44f1-4ae8-9e5d-600683dce2e8</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Connections'])[3]/preceding::span[7]</value>
      <webElementGuid>363aed75-4371-4882-b553-4e5611b8e9b3</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//div[3]/div/div[2]/div/span</value>
      <webElementGuid>25fc8005-c3e6-4a99-81bf-73751c7a96a8</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//span[(text() = 'Profile Completion' or . = 'Profile Completion')]</value>
      <webElementGuid>a7af4b27-f097-43cc-a565-710ea9d09925</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
