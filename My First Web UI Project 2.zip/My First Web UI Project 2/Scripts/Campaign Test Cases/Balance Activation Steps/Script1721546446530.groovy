import static com.kms.katalon.core.checkpoint.CheckpointFactory.findCheckpoint
import static com.kms.katalon.core.testcase.TestCaseFactory.findTestCase
import static com.kms.katalon.core.testdata.TestDataFactory.findTestData
import static com.kms.katalon.core.testobject.ObjectRepository.findTestObject
import static com.kms.katalon.core.testobject.ObjectRepository.findWindowsObject
import com.kms.katalon.core.checkpoint.Checkpoint as Checkpoint
import com.kms.katalon.core.cucumber.keyword.CucumberBuiltinKeywords as CucumberKW
import com.kms.katalon.core.mobile.keyword.MobileBuiltInKeywords as Mobile
import com.kms.katalon.core.model.FailureHandling as FailureHandling
import com.kms.katalon.core.testcase.TestCase as TestCase
import com.kms.katalon.core.testdata.TestData as TestData
import com.kms.katalon.core.testng.keyword.TestNGBuiltinKeywords as TestNGKW
import com.kms.katalon.core.testobject.TestObject as TestObject
import com.kms.katalon.core.webservice.keyword.WSBuiltInKeywords as WS
import com.kms.katalon.core.webui.keyword.WebUiBuiltInKeywords as WebUI
import com.kms.katalon.core.windows.keyword.WindowsBuiltinKeywords as Windows
import internal.GlobalVariable as GlobalVariable
import org.openqa.selenium.Keys as Keys
import static org.junit.Assert.assertEquals
import org.openqa.selenium.JavascriptExecutor as JavascriptExecutor
import com.kms.katalon.core.webui.driver.DriverFactory as DriverFactory
import org.openqa.selenium.WebDriver as WebDriver
import org.openqa.selenium.interactions.Actions as Actions

WebUI.scrollToPosition(0, 600)

Actions actions = new Actions(DriverFactory.getWebDriver())

// Scroll down
//actions.sendKeys(Keys.PAGE_DOWN).perform()
// Scroll up
actions.sendKeys(Keys.PAGE_UP).perform()

WebUI.click(findTestObject('Campaign Page Locators/Campaign Activation Page/primaryText_New'))

WebUI.waitForElementClickable(findTestObject('Campaign Page Locators/Campaign Activation Page/span_Go to Secondary Workflow'), 
    30)

WebUI.click(findTestObject('Campaign Page Locators/Campaign Activation Page/span_Go to Secondary Workflow'))

WebUI.waitForElementClickable(findTestObject('Object Repository/Balance Step objects/Page_Experience  Automation account -Dont d_67927e/div_OK'), 
    30)

WebUI.click(findTestObject('Object Repository/Balance Step objects/Page_Experience  Automation account -Dont d_67927e/div_OK'))

WebUI.waitForElementClickable(findTestObject('Balance Step objects/Page_Experience  Automation account -Dont d_67927e/div_Unpleasant'), 
    10)

WebUI.click(findTestObject('Object Repository/Balance Step objects/Page_Experience  Automation account -Dont d_67927e/div_Unpleasant'))

WebUI.waitForElementClickable(findTestObject('Campaign Page Locators/Campaign Activation Page/span_Go to Email Setup'), 
    10)

WebUI.click(findTestObject('Campaign Page Locators/Campaign Activation Page/span_Go to Email Setup'))

WebUI.waitForElementClickable(findTestObject('Object Repository/Balance Step objects/Page_Experience  Automation account -Dont d_67927e/div_Campaign Email 2'), 
    10)

WebUI.click(findTestObject('Object Repository/Balance Step objects/Page_Experience  Automation account -Dont d_67927e/div_Campaign Email 2'))

WebUI.click(findTestObject('Object Repository/Balance Step objects/Page_Experience  Automation account -Dont d_67927e/div_Survey Completed- Email Version 1'))

WebUI.click(findTestObject('Object Repository/Balance Step objects/Page_Experience  Automation account -Dont d_67927e/div_Survey Completed- Email Version 2'))

WebUI.click(findTestObject('Object Repository/Balance Step objects/Page_Experience  Automation account -Dont d_67927e/div_Secondary workflow- Follow up email'))

WebUI.click(findTestObject('Object Repository/Balance Step objects/Page_Experience  Automation account -Dont d_67927e/div_Survey retake Email'))

WebUI.waitForElementClickable(findTestObject('Object Repository/Balance Step objects/Page_Experience  Automation account -Dont d_67927e/span_Go to SMS setup'), 
    10)

WebUI.waitForElementClickable(findTestObject('Object Repository/Balance Step objects/Page_Experience  Automation account -Dont d_67927e/span_Go to SMS setup'), 
    10)

WebUI.click(findTestObject('Object Repository/Balance Step objects/Page_Experience  Automation account -Dont d_67927e/span_Go to SMS setup'))

WebUI.click(findTestObject('Object Repository/Balance Step objects/Page_Experience  Automation account -Dont d_67927e/div_Survey Reminder'))

WebUI.click(findTestObject('Object Repository/Balance Step objects/Page_Experience  Automation account -Dont d_67927e/div_Survey Completed - Happy'))

WebUI.click(findTestObject('Object Repository/Balance Step objects/Page_Experience  Automation account -Dont d_67927e/div_Survey Completed - Unhappy'))

WebUI.click(findTestObject('Object Repository/Balance Step objects/Page_Experience  Automation account -Dont d_67927e/div_Social Post Reminder'))

WebUI.click(findTestObject('Object Repository/Balance Step objects/Page_Experience  Automation account -Dont d_67927e/div_Retake Survey Request'))

WebUI.waitForElementClickable(findTestObject('Object Repository/Balance Step objects/Page_Experience  Automation account -Dont d_67927e/span_Go to Setup Configuration'), 
    10)

WebUI.click(findTestObject('Object Repository/Balance Step objects/Page_Experience  Automation account -Dont d_67927e/span_Go to Setup Configuration'))

WebUI.click(findTestObject('Object Repository/Balance Step objects/Page_Experience  Automation account -Dont d_67927e/span_User'))

WebUI.click(findTestObject('Campaign Page Locators/SetUp Configurations/Add_Source_Type'))

WebUI.click(findTestObject('Campaign Page Locators/SetUp Configurations/sftp_Source_DropDown'))

WebUI.click(findTestObject('Object Repository/Balance Step objects/Page_Experience  Automation account -Dont d_67927e/span_Activate'))

WebUI.waitForElementPresent(findTestObject('Balance Step objects/Page_Experience  Automation account -Dont d_67927e/activate_Button_In_Drawer'), 
    10)

WebUI.click(findTestObject('Balance Step objects/Page_Experience  Automation account -Dont d_67927e/activate_Button_In_Drawer'))

WebUI.waitForElementPresent(findTestObject('Balance Step objects/Page_Experience  Automation account -Dont d_67927e/activate_PopUP_Msg'), 
    30)

String activatePOPUpMsg = WebUI.getText(findTestObject('Balance Step objects/Page_Experience  Automation account -Dont d_67927e/activate_PopUP_Msg'))

assert activatePOPUpMsg == POPUP_ACTIVATE_MSG

