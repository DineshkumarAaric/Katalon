import static com.kms.katalon.core.checkpoint.CheckpointFactory.findCheckpoint
import static com.kms.katalon.core.testcase.TestCaseFactory.findTestCase
import static com.kms.katalon.core.testdata.TestDataFactory.findTestData
import static com.kms.katalon.core.testobject.ObjectRepository.findTestObject
import static com.kms.katalon.core.testobject.ObjectRepository.findWindowsObject
import com.kms.katalon.core.checkpoint.Checkpoint as Checkpoint
import com.kms.katalon.core.cucumber.keyword.CucumberBuiltinKeywords as CucumberKW
import com.kms.katalon.core.mobile.keyword.MobileBuiltInKeywords as Mobile
import com.kms.katalon.core.model.FailureHandling as FailureHandling
import com.kms.katalon.core.testcase.TestCase as TestCase
import com.kms.katalon.core.testdata.TestData as TestData
import com.kms.katalon.core.testng.keyword.TestNGBuiltinKeywords as TestNGKW
import com.kms.katalon.core.testobject.TestObject as TestObject
import com.kms.katalon.core.webservice.keyword.WSBuiltInKeywords as WS
import com.kms.katalon.core.webui.keyword.WebUiBuiltInKeywords as WebUI
import com.kms.katalon.core.windows.keyword.WindowsBuiltinKeywords as Windows
import internal.GlobalVariable as GlobalVariable
import org.openqa.selenium.Keys as Keys
import org.openqa.selenium.interactions.Actions as Actions
import com.kms.katalon.core.webui.driver.DriverFactory as DriverFactory
import com.kms.katalon.core.webui.common.WebUiCommonHelper as WebUiCommonHelper
import org.openqa.selenium.WebDriver as WebDriver
import org.openqa.selenium.WebElement as WebElement
import org.openqa.selenium.JavascriptExecutor as JavascriptExecutor

/*
WebUI.callTestCase(findTestCase('Call function/Browser Launch'), [:], FailureHandling.STOP_ON_FAILURE)

WebUI.callTestCase(findTestCase('Call function/Login'), [:], FailureHandling.STOP_ON_FAILURE)

WebUI.click(findTestObject('Accounts Page/Automation account -Dont delete - Outside Account Click'))

WebUI.scrollToPosition(0, 400)

WebUI.click(findTestObject('New Folder/Page_Experience  Automation account -Dont d_1f14a8/span_Campaigns'))

WebUI.setText(findTestObject('Campaign Page Locators/Campaign Activation Page/input_Activity Feeds_ant-input'), GlobalVariable.NewCampaignName)

WebUI.click(findTestObject('Campaign Page Locators/Campaign Activation Page/span_Edit  Activate'))
*/
WebUI.waitForElementClickable(findTestObject('Campaign Page Locators/Campaign Activation Page/First_question_Delete'), 30)

WebUI.click(findTestObject('Campaign Page Locators/Campaign Activation Page/First_question_Delete'))

WebUI.waitForElementClickable(findTestObject('Campaign Page Locators/Campaign Activation Page/div_Multiple Choice'), 30)

WebUI.click(findTestObject('Campaign Page Locators/Campaign Activation Page/div_Multiple Choice'))

WebUI.waitForElementClickable(findTestObject('Campaign Page Locators/Campaign Activation Page/div_Dynamic Field_jodit-wysiwyg draft-edits'), 
    30)

WebUI.setText(findTestObject('Campaign Page Locators/Campaign Activation Page/div_Dynamic Field_jodit-wysiwyg draft-edits'), 
    'Multiple questions')

WebUI.click(findTestObject('Campaign Page Locators/Campaign Activation Page/div_Dynamic Field_jodit-wysiwyg draft-edits'), 
    FailureHandling.STOP_ON_FAILURE)

WebUI.click(findTestObject('Campaign Page Locators/Primary Question/Question 1 btn'), FailureHandling.STOP_ON_FAILURE)

WebUI.waitForElementClickable(findTestObject('Campaign Page Locators/Primary Question/Option 1 Field in Multiple Choice'), 
    30)

WebUI.click(findTestObject('Campaign Page Locators/Primary Question/Option 1 Field in Multiple Choice'))

WebUI.waitForElementClickable(findTestObject('Campaign Page Locators/Primary Question/Option 2 Field in Multple Choice'), 
    30)

WebUI.click(findTestObject('Campaign Page Locators/Primary Question/Option 2 Field in Multple Choice'))

WebUI.setText(findTestObject('Campaign Page Locators/Primary Question/Option 1 Field in Multiple Choice'), 'Option1')

WebUI.waitForElementClickable(findTestObject('Campaign Page Locators/Primary Question/Option 2 Field in Multple Choice'), 
    30)

WebUI.setText(findTestObject('Campaign Page Locators/Primary Question/Option 2 Field in Multple Choice'), 'Option2')

WebUI.click(findTestObject('Campaign Page Locators/Primary Question/Option 1 Field in Multiple Choice'))

WebUI.waitForElementClickable(findTestObject('Campaign Page Locators/Campaign Activation Page/div_Dynamic Field_jodit-wysiwyg draft-edits'), 
    30)

WebUI.click(findTestObject('Campaign Page Locators/Campaign Activation Page/div_Dynamic Field_jodit-wysiwyg draft-edits'), 
    FailureHandling.STOP_ON_FAILURE)

WebUI.click(findTestObject('Campaign Page Locators/Campaign Activation Page/div_Matrix Question'))

WebUI.waitForElementClickable(findTestObject('Campaign Page Locators/Primary Question/Matrix Question Field'), 30)

WebUI.setText(findTestObject('Campaign Page Locators/Primary Question/Matrix Question Field'), 'Matrix Questions')

WebUI.scrollToPosition(0, 300)

WebUI.click(findTestObject('Campaign Page Locators/Primary Question/Matrix Question Field'), FailureHandling.STOP_ON_FAILURE)

WebUI.scrollToElement(findTestObject('Campaign Page Locators/Primary Question/Primary Question Text'), 30)

JavascriptExecutor js = ((DriverFactory.getWebDriver()) as JavascriptExecutor)

//JavascriptExecutor js = (JavascriptExecutor) driver;
js.executeScript('document.querySelector(\'.ant-card-body\').scrollTop=-600')

WebUI.waitForElementClickable(findTestObject('Campaign Page Locators/Primary Question/Matrix Row1'), 30)

WebUI.click(findTestObject('Campaign Page Locators/Primary Question/Matrix Row1'))

WebUI.waitForElementClickable(findTestObject('Campaign Page Locators/Primary Question/Matrix Row1'), 30)

WebUI.setText(findTestObject('Campaign Page Locators/Primary Question/Matrix Row1'), 'Row1')

WebUI.waitForElementClickable(findTestObject('Campaign Page Locators/Primary Question/Matrix Question Row 2'), 30)

WebUI.click(findTestObject('Campaign Page Locators/Primary Question/Matrix Question Row 2'))

WebUI.waitForElementClickable(findTestObject('Campaign Page Locators/Primary Question/Matrix Question Row 2'), 30)

WebUI.setText(findTestObject('Campaign Page Locators/Primary Question/Matrix Question Row 2'), 'Row2')

WebUI.waitForElementClickable(findTestObject('Campaign Page Locators/Primary Question/Matrix Row1'), 30)

WebUI.click(findTestObject('Campaign Page Locators/Primary Question/Matrix Row1'))

WebUI.waitForElementClickable(findTestObject('Campaign Page Locators/Primary Question/Upload Question Button'), 10)

WebUI.click(findTestObject('Campaign Page Locators/Primary Question/Upload Question Button'), FailureHandling.STOP_ON_FAILURE)

WebUI.waitForElementClickable(findTestObject('Campaign Page Locators/Primary Question/Upload Question_Field'), 10)

WebUI.setText(findTestObject('Campaign Page Locators/Primary Question/Upload Question_Field'), 'Upload Questions')

WebUI.waitForElementClickable(findTestObject('Campaign Page Locators/Primary Question/Upload Question_Field'), 30)

WebUI.click(findTestObject('Campaign Page Locators/Primary Question/Upload Question_Field'), FailureHandling.STOP_ON_FAILURE)

WebUI.waitForElementClickable(findTestObject('Campaign Page Locators/Primary Question/Question 3 Btn'), 10)

WebUI.click(findTestObject('Campaign Page Locators/Primary Question/Question 3 Btn'), FailureHandling.STOP_ON_FAILURE)

WebUI.waitForElementClickable(findTestObject('Campaign Page Locators/Primary Question/Allowable file format Field'), 10)

WebUI.click(findTestObject('Campaign Page Locators/Primary Question/Allowable file format Field'), FailureHandling.STOP_ON_FAILURE)

WebUI.click(findTestObject('Object Repository/Campaign Page Locators/Campaign Activation Page/div_jpg'), FailureHandling.STOP_ON_FAILURE)

WebUI.click(findTestObject('Object Repository/Campaign Page Locators/Campaign Activation Page/div_png'), FailureHandling.STOP_ON_FAILURE)

WebUI.click(findTestObject('Object Repository/Campaign Page Locators/Campaign Activation Page/div_doc'), FailureHandling.STOP_ON_FAILURE)

WebUI.click(findTestObject('Object Repository/Campaign Page Locators/Campaign Activation Page/div_xlsx'), FailureHandling.STOP_ON_FAILURE)

WebUI.click(findTestObject('Object Repository/Campaign Page Locators/Campaign Activation Page/div_csv'))

WebUI.click(findTestObject('Campaign Page Locators/Primary Question/Rating Scale'))

WebUI.waitForElementClickable(findTestObject('Campaign Page Locators/Primary Question/Rating Scale Field'), 10)

WebUI.setText(findTestObject('Campaign Page Locators/Primary Question/Rating Scale Field'), 'Rating Scale')

WebUI.waitForElementVisible(findTestObject('Campaign Page Locators/Primary Question/required_Error_Msg'), 30)

WebUI.scrollToElement(findTestObject('Campaign Page Locators/Primary Question/required_Error_Msg'), 30)

WebUI.scrollToElement(findTestObject('Campaign Page Locators/Primary Question/Question 4 btn'), 30)

WebUI.click(findTestObject('Campaign Page Locators/Primary Question/Rating Scale Field'), FailureHandling.CONTINUE_ON_FAILURE)

WebUI.waitForElementClickable(findTestObject('Campaign Page Locators/Primary Question/Poor field'), 10)

WebUI.click(findTestObject('Campaign Page Locators/Primary Question/Poor field'))

WebUI.waitForElementClickable(findTestObject('Campaign Page Locators/Campaign Activation Page/div_Slider Question'), 30)

WebUI.click(findTestObject('Campaign Page Locators/Campaign Activation Page/div_Slider Question'))

WebUI.waitForElementClickable(findTestObject('Campaign Page Locators/Primary Question/Slider question field'), 10)

WebUI.setText(findTestObject('Campaign Page Locators/Primary Question/Slider question field'), 'Slider Question')

WebUI.waitForElementVisible(findTestObject('Campaign Page Locators/Primary Question/required_Error_Msg'), 30)

WebUI.scrollToElement(findTestObject('Campaign Page Locators/Primary Question/required_Error_Msg'), 30)

WebUI.scrollToElement(findTestObject('Campaign Page Locators/Primary Question/Question 5 btn'), 30)

WebUI.click(findTestObject('Campaign Page Locators/Primary Question/Slider question field'), FailureHandling.STOP_ON_FAILURE)

WebUI.click(findTestObject('Campaign Page Locators/Primary Question/slider_Start_Value'), FailureHandling.STOP_ON_FAILURE)

WebUI.waitForElementClickable(findTestObject('Campaign Page Locators/Campaign Activation Page/div_Likert Scale Question'), 
    30)

WebUI.click(findTestObject('Campaign Page Locators/Campaign Activation Page/div_Likert Scale Question'))

WebUI.waitForElementClickable(findTestObject('Campaign Page Locators/Primary Question/Likert scale Question field'), 10)

WebUI.setText(findTestObject('Campaign Page Locators/Primary Question/Likert scale Question field'), 'Scale Question')

WebUI.waitForElementVisible(findTestObject('Campaign Page Locators/Primary Question/required_Error_Msg'), 30)

WebUI.scrollToElement(findTestObject('Campaign Page Locators/Primary Question/required_Error_Msg'), 30)

WebUI.scrollToElement(findTestObject('Campaign Page Locators/Primary Question/Question 6 btn'), 30)

WebUI.click(findTestObject('Campaign Page Locators/Primary Question/Likert scale Question field'), FailureHandling.STOP_ON_FAILURE)

WebUI.waitForElementClickable(findTestObject('Campaign Page Locators/Primary Question/scale_Question_StronglyAgree_Option1'), 
    30)

WebUI.click(findTestObject('Campaign Page Locators/Primary Question/scale_Question_StronglyAgree_Option1'), FailureHandling.STOP_ON_FAILURE)

WebUI.waitForElementClickable(findTestObject('Campaign Page Locators/Campaign Activation Page/div_Open Ended'), 30)

WebUI.click(findTestObject('Campaign Page Locators/Campaign Activation Page/div_Open Ended'))

WebUI.waitForElementClickable(findTestObject('Campaign Page Locators/Primary Question/Open Ended Field'), 10)

//WebUI.scrollToElement(findTestObject('Campaign Activation Page/Primary Question/Rating Scale Field'), 10)
WebUI.setText(findTestObject('Campaign Page Locators/Primary Question/Open Ended Field'), 'Open Ended')

WebUI.waitForElementVisible(findTestObject('Campaign Page Locators/Primary Question/required_Error_Msg'), 30)

WebUI.scrollToElement(findTestObject('Campaign Page Locators/Primary Question/required_Error_Msg'), 30)

WebUI.scrollToElement(findTestObject('Campaign Page Locators/Primary Question/Question 7 btn'), 30)

WebUI.click(findTestObject('Campaign Page Locators/Primary Question/Open Ended Field'), FailureHandling.STOP_ON_FAILURE)

WebUI.click(findTestObject('Campaign Page Locators/Primary Question/open_Ended_PlaceholderField'), FailureHandling.STOP_ON_FAILURE)

WebUI.waitForElementClickable(findTestObject('Campaign Page Locators/Campaign Activation Page/div_Dropdown'), 30)

WebUI.click(findTestObject('Campaign Page Locators/Campaign Activation Page/div_Dropdown'))

WebUI.waitForElementClickable(findTestObject('Campaign Page Locators/Primary Question/DropDown Field'), 30)

WebUI.setText(findTestObject('Campaign Page Locators/Primary Question/DropDown Field'), 'DropDown Question')

WebUI.waitForElementPresent(findTestObject('Campaign Page Locators/Primary Question/required_Error_Msg'), 30)

WebUI.scrollToElement(findTestObject('Campaign Page Locators/Primary Question/required_Error_Msg'), 30)

WebUI.setText(findTestObject('Campaign Page Locators/Primary Question/Dropdown Choice 1'), 'Option1')

WebUI.waitForElementClickable(findTestObject('Campaign Page Locators/Primary Question/Dropdown Choice 2'), 10)

WebUI.click(findTestObject('Campaign Page Locators/Primary Question/Dropdown Choice 2'), FailureHandling.STOP_ON_FAILURE)

WebUI.setText(findTestObject('Campaign Page Locators/Primary Question/Dropdown Choice 2'), 'Option2')

WebUI.mouseOver(findTestObject('Campaign Page Locators/Primary Question/Dropdown Choice 1'), FailureHandling.STOP_ON_FAILURE)

WebUI.mouseOver(findTestObject('Campaign Page Locators/Primary Question/DropDown Field'), FailureHandling.STOP_ON_FAILURE)

WebUI.click(findTestObject('Campaign Page Locators/Primary Question/DropDown Field'))

WebUI.scrollToPosition(0, 600)

WebUI.click(findTestObject('Campaign Page Locators/Primary Question/DropDown Field'))

WebUI.click(findTestObject('Campaign Page Locators/Primary Question/Question 8 btn'))

WebUI.waitForElementClickable(findTestObject('Campaign Page Locators/Campaign Activation Page/div_Ranking Question'), 30)

WebUI.click(findTestObject('Campaign Page Locators/Campaign Activation Page/div_Ranking Question'))

WebUI.waitForElementClickable(findTestObject('Campaign Page Locators/Primary Question/Ranking Question'), 10)

WebUI.setText(findTestObject('Campaign Page Locators/Primary Question/Ranking Question'), 'Ranking Question')

WebUI.click(findTestObject('Campaign Page Locators/Primary Question/Ranking Question'), FailureHandling.STOP_ON_FAILURE)

WebUI.click(findTestObject('Campaign Page Locators/Primary Question/Ranking Question Option 1 field'))

WebUI.scrollToPosition(0, 600)

WebUI.setText(findTestObject('Campaign Page Locators/Primary Question/Ranking Question Option 1 field'), 'Option1')

WebUI.waitForElementClickable(findTestObject('Campaign Page Locators/Primary Question/Ranking Question Option 1 field'), 
    30)

WebUI.click(findTestObject('Campaign Page Locators/Primary Question/Ranking Question Option 1 field'))

WebUI.setText(findTestObject('Campaign Page Locators/Primary Question/Ranking Question Option 2 Field'), 'Option2')

WebUI.click(findTestObject('Campaign Page Locators/Primary Question/Ranking Question Option 3 Field'))

WebUI.setText(findTestObject('Campaign Page Locators/Primary Question/Ranking Question Option 3 Field'), 'Option3')

WebUI.click(findTestObject('Campaign Page Locators/Primary Question/Ranking Question Option 4 Field'))

WebUI.setText(findTestObject('Campaign Page Locators/Primary Question/Ranking Question Option 4 Field'), 'Option4')

WebUI.click(findTestObject('Campaign Page Locators/Primary Question/Ranking Question Option 5 Field'))

WebUI.setText(findTestObject('Campaign Page Locators/Primary Question/Ranking Question Option 5 Field'), 'Option5')

WebUI.click(findTestObject('Campaign Page Locators/Primary Question/Ranking Question Option 1 field'))

WebUI.click(findTestObject('Campaign Page Locators/Campaign Activation Page/div_Image Question'))

WebUI.setText(findTestObject('Campaign Page Locators/Primary Question/image Question'), 'Image Question')

WebUI.click(findTestObject('Campaign Page Locators/Primary Question/image Question'), FailureHandling.STOP_ON_FAILURE)

String relativeImagePath1 = 'Images/Award1.png'

String relativeImagePath2 = 'Images/Award2.png'

// Get the absolute path to the file
String projectDir = System.getProperty('user.dir')

String filePath1 = (System.getProperty('user.dir') + '/') + relativeImagePath1

String filePath2 = (System.getProperty('user.dir') + '/') + relativeImagePath2

// there's an input field with ID 'file-upload' for file upload
WebUI.sendKeys(findTestObject('Campaign Page Locators/Primary Question/Image Upload 1'), filePath1)

WebUI.click(findTestObject('Campaign Page Locators/Primary Question/Image Upload Field'))

WebUI.waitForElementClickable(findTestObject('Campaign Page Locators/Primary Question/Image Upload Field'), 30)

WebUI.click(findTestObject('Campaign Page Locators/Primary Question/Image Upload Field'))

WebUI.setText(findTestObject('Campaign Page Locators/Primary Question/Image Upload Field'), 'Image1')

WebUI.waitForElementClickable(findTestObject('Campaign Page Locators/Primary Question/Image Upload 2'), 30)

WebUI.sendKeys(findTestObject('Campaign Page Locators/Primary Question/Image Upload 2'), filePath2)

WebUI.click(findTestObject('Campaign Page Locators/Primary Question/Image Upload field 2'))

WebUI.setText(findTestObject('Campaign Page Locators/Primary Question/Image Upload field 2'), 'Image2')

WebUI.setText(findTestObject('Campaign Page Locators/Primary Question/disclaimer_Field'), 'If your blog allows others to post content, such as with blog post commenting, or if you provide links to third-party resources, consider a content disclaimer. ')

WebUI.scrollToElement(findTestObject('Campaign Page Locators/Primary Question/secondary_Workflow_TopSideLink'), 10)

WebUI.scrollToElement(findTestObject('Campaign Page Locators/Primary Question/Question 1 btn'), 10)

