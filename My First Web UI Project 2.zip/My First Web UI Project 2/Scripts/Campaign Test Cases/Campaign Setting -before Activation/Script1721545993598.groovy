import static com.kms.katalon.core.checkpoint.CheckpointFactory.findCheckpoint
import static com.kms.katalon.core.testcase.TestCaseFactory.findTestCase
import static com.kms.katalon.core.testdata.TestDataFactory.findTestData
import static com.kms.katalon.core.testobject.ObjectRepository.findTestObject
import static com.kms.katalon.core.testobject.ObjectRepository.findWindowsObject
import com.kms.katalon.core.checkpoint.Checkpoint as Checkpoint
import com.kms.katalon.core.cucumber.keyword.CucumberBuiltinKeywords as CucumberKW
import com.kms.katalon.core.mobile.keyword.MobileBuiltInKeywords as Mobile
import com.kms.katalon.core.model.FailureHandling as FailureHandling
import com.kms.katalon.core.testcase.TestCase as TestCase
import com.kms.katalon.core.testdata.TestData as TestData
import com.kms.katalon.core.testng.keyword.TestNGBuiltinKeywords as TestNGKW
import com.kms.katalon.core.testobject.TestObject as TestObject
import com.kms.katalon.core.webservice.keyword.WSBuiltInKeywords as WS
import com.kms.katalon.core.webui.keyword.WebUiBuiltInKeywords as WebUI
import com.kms.katalon.core.windows.keyword.WindowsBuiltinKeywords as Windows
import internal.GlobalVariable as GlobalVariable
import org.openqa.selenium.Keys as Keys

/*
WebUI.callTestCase(findTestCase('Call function/Browser Launch'), [:], FailureHandling.STOP_ON_FAILURE)

WebUI.callTestCase(findTestCase('Call function/Login'), [:], FailureHandling.STOP_ON_FAILURE)

WebUI.click(findTestObject('Accounts Page/Automation account -Dont delete - Outside Account Click'))
*/
WebUI.click(findTestObject('Submenu Locators/Campaigns Submenu'))

WebUI.setText(findTestObject('Object Repository/Settings/General Settings/input_Activity Feeds_ant-input'), GlobalVariable.NewCampaignName)

WebUI.waitForElementClickable(findTestObject('Object Repository/Settings/General Settings/span_Edit  Activate'), 30)

WebUI.click(findTestObject('Object Repository/Settings/General Settings/span_Edit  Activate'))

WebUI.waitForElementClickable(findTestObject('Object Repository/Settings/General Settings/button_Settings'), 30)

WebUI.click(findTestObject('Object Repository/Settings/General Settings/button_Settings'))

WebUI.waitForElementClickable(findTestObject('Object Repository/Settings/Delivery Settings/button_Allow anonymous surveys_settings_all_df849f'), 
    30)

WebUI.click(findTestObject('Object Repository/Settings/Delivery Settings/button_Allow anonymous surveys_settings_all_df849f'))

WebUI.waitForElementPresent(findTestObject('Object Repository/Settings/Delivery Settings/div_Anonymous Survey'), 30)

WebUI.getText(findTestObject('Object Repository/Settings/Delivery Settings/div_Anonymous Survey'))

WebUI.click(findTestObject('Object Repository/Settings/Delivery Settings/div_Upon enabling anonymous surveys, please_14729a'))

WebUI.waitForElementVisible(findTestObject('Settings/Delivery Settings/button_Close'), 30)

WebUI.waitForElementClickable(findTestObject('Settings/Delivery Settings/button_Close'), 30)

WebUI.click(findTestObject('Object Repository/Settings/Delivery Settings/button_Close'))

WebUI.click(findTestObject('Object Repository/Settings/Delivery Settings/button_Allow anonymous surveys_settings_all_df849f'))

WebUI.click(findTestObject('Object Repository/Settings/Delivery Settings/button_Allow manual surveys_settings_allowM_a19665'))

WebUI.click(findTestObject('Object Repository/Settings/Delivery Settings/div_Delivery Settings'))

WebUI.click(findTestObject('Object Repository/Settings/Delivery Settings/div_Send Now'))

WebUI.click(findTestObject('Object Repository/Settings/Delivery Settings/div_Send in bulk_ant-switch-handle'))

WebUI.click(findTestObject('Object Repository/Settings/Delivery Settings/div_Campaign would be triggered at current _c38a29'))

WebUI.click(findTestObject('Object Repository/Settings/Delivery Settings/span_experience.com'))

WebUI.click(findTestObject('Object Repository/Settings/Delivery Settings/div_Back'))

WebUI.click(findTestObject('Object Repository/Settings/Delivery Settings/circle'))

