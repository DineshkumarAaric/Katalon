import static com.kms.katalon.core.checkpoint.CheckpointFactory.findCheckpoint
import static com.kms.katalon.core.testcase.TestCaseFactory.findTestCase
import static com.kms.katalon.core.testdata.TestDataFactory.findTestData
import static com.kms.katalon.core.testobject.ObjectRepository.findTestObject
import static com.kms.katalon.core.testobject.ObjectRepository.findWindowsObject
import com.kms.katalon.core.checkpoint.Checkpoint as Checkpoint
import com.kms.katalon.core.cucumber.keyword.CucumberBuiltinKeywords as CucumberKW
import com.kms.katalon.core.mobile.keyword.MobileBuiltInKeywords as Mobile
import com.kms.katalon.core.model.FailureHandling as FailureHandling
import com.kms.katalon.core.testcase.TestCase as TestCase
import com.kms.katalon.core.testdata.TestData as TestData
import com.kms.katalon.core.testng.keyword.TestNGBuiltinKeywords as TestNGKW
import com.kms.katalon.core.testobject.TestObject as TestObject
import com.kms.katalon.core.webservice.keyword.WSBuiltInKeywords as WS
import com.kms.katalon.core.webui.keyword.WebUiBuiltInKeywords as WebUI
import com.kms.katalon.core.windows.keyword.WindowsBuiltinKeywords as Windows
import internal.GlobalVariable as GlobalVariable
import org.openqa.selenium.Keys as Keys
import com.kms.katalon.core.webui.driver.DriverFactory as DriverFactory
import org.openqa.selenium.WebDriver as WebDriver
import org.openqa.selenium.WebElement as WebElement
import org.openqa.selenium.By as By

WebUI.callTestCase(findTestCase('Call function/Browser Launch'), [:], FailureHandling.STOP_ON_FAILURE)

WebUI.callTestCase(findTestCase('Call function/Agent_Login'), [:], FailureHandling.STOP_ON_FAILURE)

WebUI.callTestCase(findTestCase('Call function/Agent PopUP Close'), [:], FailureHandling.STOP_ON_FAILURE)

WebUI.click(findTestObject('Object Repository/agentProfile_Page/span_Dashboard'))

String intial_Score = WebUI.getText(findTestObject('Object Repository/agentDashboard_Page/span_172'))

int integerValue_initial = intial_Score.toInteger()

GlobalVariable.SRS_INITIAL = integerValue_initial

println(integerValue_initial)

WebUI.comment(integerValue_initial.toString())

WebUI.click(findTestObject('Object Repository/agentDashboard_Page/span_Profile Completion'))

WebUI.click(findTestObject('Object Repository/agentProfile_Page/button_KKR_ant-btn ant-btn-link'))

WebUI.mouseOver(findTestObject('agentProfile_Page/circle'))

String locator = '//div[text()=\'Add Photo\']'

//WebDriver driver = DriverFactory.getWebDriver()
List<WebElement> elementlist = DriverFactory.getWebDriver().findElements(By.xpath(locator))

print(elementlist.size())

int size = elementlist.size()

if (size == 1) {
    WebUI.click(findTestObject('Object Repository/agentProfile_Page/div_Add Photo'))
} else {
}

String relativeImagePath1 = 'Images/Award1.png'

// Get the absolute path to the file
String projectDir = System.getProperty('user.dir')

String filePath1 = (System.getProperty('user.dir') + '/') + relativeImagePath1

// there's an input field with ID 'file-upload' for file upload
WebUI.sendKeys(findTestObject('agentProfile_Page/path'), filePath1)

WebUI.waitForElementClickable(findTestObject('agentProfile_Page/upload_Button'), 30)

WebUI.click(findTestObject('agentProfile_Page/upload_Button'))

WebUI.waitForElementVisible(findTestObject('agentProfile_Page/profile_Upload_SuccessMsg'), 30)

String actualPopUp_imageUpload = WebUI.getText(findTestObject('agentProfile_Page/profile_Upload_SuccessMsg'), FailureHandling.STOP_ON_FAILURE)

assert actualPopUp_imageUpload == EXPECTED_IMAGE_UPLOAD_POPUP

WebUI.waitForElementClickable(findTestObject('agentProfile_Page/profile_Save'), 30)

WebUI.click(findTestObject('agentProfile_Page/profile_Save'))

WebUI.waitForElementVisible(findTestObject('agentProfile_Page/profile_Upload_SuccessMsg'), 30)

String actualPopUp_EditSave = WebUI.getText(findTestObject('agentProfile_Page/profile_Upload_SuccessMsg'), FailureHandling.STOP_ON_FAILURE)

WebUI.click(findTestObject('Object Repository/agentProfile_Page/span_Dashboard'))
Thread.sleep(4000)

String after_score = WebUI.getText(findTestObject('Object Repository/agentDashboard_Page/span_172'))

int integerValue_after = after_score.toInteger()

GlobalVariable.SRS_AFTER = integerValue_after 

assert GlobalVariable.SRS_AFTER  == (GlobalVariable.SRS_INITIAL + 5)

