import static com.kms.katalon.core.checkpoint.CheckpointFactory.findCheckpoint
import static com.kms.katalon.core.testcase.TestCaseFactory.findTestCase
import static com.kms.katalon.core.testdata.TestDataFactory.findTestData
import static com.kms.katalon.core.testobject.ObjectRepository.findTestObject
import static com.kms.katalon.core.testobject.ObjectRepository.findWindowsObject
import com.kms.katalon.core.checkpoint.Checkpoint as Checkpoint
import com.kms.katalon.core.cucumber.keyword.CucumberBuiltinKeywords as CucumberKW
import com.kms.katalon.core.mobile.keyword.MobileBuiltInKeywords as Mobile
import com.kms.katalon.core.model.FailureHandling as FailureHandling
import com.kms.katalon.core.testcase.TestCase as TestCase
import com.kms.katalon.core.testdata.TestData as TestData
import com.kms.katalon.core.testng.keyword.TestNGBuiltinKeywords as TestNGKW
import com.kms.katalon.core.testobject.TestObject as TestObject
import com.kms.katalon.core.webservice.keyword.WSBuiltInKeywords as WS
import com.kms.katalon.core.webui.keyword.WebUiBuiltInKeywords as WebUI
import com.kms.katalon.core.windows.keyword.WindowsBuiltinKeywords as Windows
import internal.GlobalVariable as GlobalVariable
import org.openqa.selenium.Keys as Keys
import com.kms.katalon.core.util.KeywordUtil as KeywordUtil
import com.kms.katalon.core.testobject.ConditionType as ConditionType
import org.openqa.selenium.WebElement as WebElement
import static org.junit.Assert.assertEquals

WebUI.click(findTestObject('Submenu Locators/Campaigns Submenu'))

WebUI.waitForElementVisible(findTestObject('Object Repository/Campaign Page Locators/Campaign Dashboard/Campaign Breadcum'), 
    30)

String Actual_CampaignBreadcum = WebUI.getText(findTestObject('Object Repository/Campaign Page Locators/Campaign Dashboard/Campaign Breadcum'))

assert Actual_CampaignBreadcum == GlobalVariable.EXPECTED_CAMPAIGN_BREADCUM

boolean condition = WebUI.waitForElementPresent(findTestObject('Campaign Page Locators/Campaign Dashboard/Capaign Grid View Locator'), 
    30)

assert condition == true

boolean condition2 = WebUI.waitForElementPresent(findTestObject('Campaign Page Locators/Campaign Dashboard/campaigns_Groups_Card'), 
    30)

assert condition2 == true

WebUI.scrollToElement(findTestObject('Campaign Page Locators/Campaign Dashboard/deactivated_Campaign_Cards'), 300)

boolean condition3 = WebUI.waitForElementPresent(findTestObject('Campaign Page Locators/Campaign Dashboard/deactivated_Campaign_Cards'), 
    30)

assert condition3 == true

WebUI.click(findTestObject('Campaign Page Locators/Campaign Dashboard/deactivated_Campaign_Cards'))

TestObject elementslocator = new TestObject()

elementslocator.addProperty('xpath', ConditionType.EQUALS, '//span[contains(text(),\'Deactivated\')]')

List<WebElement> DeactivatedCampaignList = WebUI.findWebElements(elementslocator, 30)

int DeactivatedCampaignListSize = DeactivatedCampaignList.size()

assert DeactivatedCampaignListSize == 10

