import static com.kms.katalon.core.checkpoint.CheckpointFactory.findCheckpoint
import static com.kms.katalon.core.testcase.TestCaseFactory.findTestCase
import static com.kms.katalon.core.testdata.TestDataFactory.findTestData
import static com.kms.katalon.core.testobject.ObjectRepository.findTestObject
import static com.kms.katalon.core.testobject.ObjectRepository.findWindowsObject
import com.kms.katalon.core.checkpoint.Checkpoint as Checkpoint
import com.kms.katalon.core.cucumber.keyword.CucumberBuiltinKeywords as CucumberKW
import com.kms.katalon.core.mobile.keyword.MobileBuiltInKeywords as Mobile
import com.kms.katalon.core.model.FailureHandling as FailureHandling
import com.kms.katalon.core.testcase.TestCase as TestCase
import com.kms.katalon.core.testdata.TestData as TestData
import com.kms.katalon.core.testng.keyword.TestNGBuiltinKeywords as TestNGKW
import com.kms.katalon.core.testobject.TestObject as TestObject
import com.kms.katalon.core.webservice.keyword.WSBuiltInKeywords as WS
import com.kms.katalon.core.webui.keyword.WebUiBuiltInKeywords as WebUI
import com.kms.katalon.core.windows.keyword.WindowsBuiltinKeywords as Windows
import internal.GlobalVariable as GlobalVariable
import org.openqa.selenium.Keys as Keys
import com.kms.katalon.core.util.KeywordUtil as KeywordUtil
import com.kms.katalon.core.testobject.ConditionType as ConditionType
import org.openqa.selenium.WebElement as WebElement
import static org.junit.Assert.assertEquals

/*if (Actual_AccManager_DashboardBreadcum.equals(GlobalVariable.EXPECTED_ACCOUNTMANAGER_DASHBOARD_BREADCUM)) {
    KeywordUtil.markPassed('The text value matches the expected value.')
} else {
    KeywordUtil.markFailed(((('The text value does not match. Expected: \'' + Actual_AccManager_DashboardBreadcum) + '\', but was: \'') + 
        GlobalVariable.EXPECTED_ACCOUNTMANAGER_DASHBOARD_BREADCUM) + '\'')
}
*/
WebUI.click(findTestObject('Submenu Locators/Campaigns Submenu'))

WebUI.waitForElementVisible(findTestObject('Object Repository/Campaign Page Locators/Campaign Dashboard/Campaign Breadcum'), 
    30)

String Actual_CampaignBreadcum = WebUI.getText(findTestObject('Object Repository/Campaign Page Locators/Campaign Dashboard/Campaign Breadcum'))

assert Actual_CampaignBreadcum == GlobalVariable.EXPECTED_CAMPAIGN_BREADCUM

WebUI.waitForElementPresent(findTestObject('Campaign Page Locators/Campaign Dashboard/Cardview Button'), 30)

//WebUI.click(findTestObject('Campaign Page Locators/Campaign Dashboard/Cardview Button'))
WebUI.click(findTestObject('Object Repository/Campaign Page Locators/Campaign Dashboard/Click Search Field'), FailureHandling.STOP_ON_FAILURE)

WebUI.setText(findTestObject('Object Repository/Campaign Page Locators/Campaign Dashboard/Click Search Field'), 'Automation')

WebUI.click(findTestObject('Campaign Page Locators/Campaign Dashboard/View Analytics Link'))

WebUI.waitForElementVisible(findTestObject('Campaign Page Locators/Campaign OverView/Automation Survey Text'), 30)

TestObject elementsLocator = new TestObject()

elementsLocator.addProperty('xpath', ConditionType.EQUALS, '//div[text()=\'Automated Survey\']//following::canvas')

List<WebElement> elementsList = WebUI.findWebElements(elementsLocator, 30)

int elementsSize = elementsList.size()

assert elementsSize == 4

WebUI.click(findTestObject('Campaign Page Locators/Campaign OverView/Today Filter'))

assert elementsSize == 4

WebUI.click(findTestObject('Campaign Page Locators/Campaign OverView/7 Day Filter'))

assert elementsSize == 4

WebUI.click(findTestObject('Campaign Page Locators/Campaign OverView/1Month filter'))

assert elementsSize == 4

WebUI.click(findTestObject('Campaign Page Locators/Campaign OverView/6Month Filter'))

assert elementsSize == 4

WebUI.click(findTestObject('Campaign Page Locators/Campaign OverView/1Year Filter'))

assert elementsSize == 4

WebUI.click(findTestObject('Campaign Page Locators/Campaign OverView/All Filter'))

