import static com.kms.katalon.core.checkpoint.CheckpointFactory.findCheckpoint
import static com.kms.katalon.core.testcase.TestCaseFactory.findTestCase
import static com.kms.katalon.core.testdata.TestDataFactory.findTestData
import static com.kms.katalon.core.testobject.ObjectRepository.findTestObject
import static com.kms.katalon.core.testobject.ObjectRepository.findWindowsObject
import com.kms.katalon.core.checkpoint.Checkpoint as Checkpoint
import com.kms.katalon.core.cucumber.keyword.CucumberBuiltinKeywords as CucumberKW
import com.kms.katalon.core.mobile.keyword.MobileBuiltInKeywords as Mobile
import com.kms.katalon.core.model.FailureHandling as FailureHandling
import com.kms.katalon.core.testcase.TestCase as TestCase
import com.kms.katalon.core.testdata.TestData as TestData
import com.kms.katalon.core.testng.keyword.TestNGBuiltinKeywords as TestNGKW
import com.kms.katalon.core.testobject.TestObject as TestObject
import com.kms.katalon.core.webservice.keyword.WSBuiltInKeywords as WS
import com.kms.katalon.core.webui.keyword.WebUiBuiltInKeywords as WebUI
import com.kms.katalon.core.windows.keyword.WindowsBuiltinKeywords as Windows
import internal.GlobalVariable as GlobalVariable
import org.openqa.selenium.Keys as Keys
import com.kms.katalon.core.util.KeywordUtil as KeywordUtil
import com.kms.katalon.core.testobject.ConditionType as ConditionType
import org.openqa.selenium.WebElement as WebElement
import static org.junit.Assert.assertEquals
/*

 WebUI.callTestCase(findTestCase('Call function/Browser Launch'), [:], FailureHandling.STOP_ON_FAILURE)
 
 WebUI.callTestCase(findTestCase('Call function/Login'), [:], FailureHandling.STOP_ON_FAILURE)
 
 WebUI.click(findTestObject('Accounts Page/Automation account -Dont delete - Outside Account Click'))
 
 WebUI.waitForElementPresent(findTestObject('Dashboard Page/Account Manager Dashboard'), 30)
 
*/


WebUI.click(findTestObject('Submenu Locators/Campaigns Submenu'))

WebUI.waitForElementVisible(findTestObject('Object Repository/Campaign Page Locators/Campaign Dashboard/Campaign Breadcum'), 
    30)

String Actual_CampaignBreadcum = WebUI.getText(findTestObject('Object Repository/Campaign Page Locators/Campaign Dashboard/Campaign Breadcum'))

assert Actual_CampaignBreadcum == GlobalVariable.EXPECTED_CAMPAIGN_BREADCUM

WebUI.click(findTestObject('Campaign Page Locators/Activity Feed Page/div_Activity Feeds'))

WebUI.waitForElementPresent(findTestObject('Campaign Page Locators/Activity Feed Page/activity_Feed_HeaderText'), 30)

String Actual_ActivityFeed_HeaderText = WebUI.getText(findTestObject('Campaign Page Locators/Activity Feed Page/activity_Feed_HeaderText'), 
    FailureHandling.STOP_ON_FAILURE)

assert Actual_ActivityFeed_HeaderText == EXPECTED_ACTIVITYFEED_TEXT

WebUI.click(findTestObject('Campaign Page Locators/Activity Feed Page/a_View All Activity'))

WebUI.waitForElementPresent(findTestObject('Campaign Page Locators/Activity Feed Page/activity_Feed_Breadcum'), 30)

String Actual_ActivityFeed_Breadcum = WebUI.getText(findTestObject('Campaign Page Locators/Activity Feed Page/activity_Feed_Breadcum'), 
    FailureHandling.STOP_ON_FAILURE)

assert Actual_ActivityFeed_Breadcum == EXPECTED_ACTIVITYFEED_BREADCUM

WebUI.click(findTestObject('Object Repository/Campaign Page Locators/Activity Feed Page/svg'))

WebUI.click(findTestObject('Campaign Page Locators/Activity Feed Page/start_Date_Field_Filter'))

WebUI.click(findTestObject('Campaign Page Locators/Activity Feed Page/pick_StartDate_Calender'))

WebUI.click(findTestObject('Campaign Page Locators/Activity Feed Page/pick_EndDate_Calender'))

Thread.sleep(5000);

WebUI.waitForElementPresent(findTestObject('Campaign Page Locators/Activity Feed Page/table_Body'), 30)

TestObject elementslocator = new TestObject()

elementslocator.addProperty('xpath', ConditionType.EQUALS, '//tbody/tr/td[@class=\'ant-table-cell\'][2]/div')

List<WebElement> ActivityListTime = WebUI.findWebElements(elementslocator, 30)

if (ActivityListTime.size() > 0) {
    for (WebElement element : ActivityListTime) {
        String elementText = element.getText()
         println(elementText)
        if (elementText.contains('min ago') || elementText.contains('hr ago')|| elementText.contains('sec ago')) {
            KeywordUtil.markPassed('The text value matches the expected value.')
        } else {
			print(element.getText())
            KeywordUtil.markFailed('one of the list did not match with the keyword')
        }
    }
} else {
    WebUI.waitForElementPresent(findTestObject('Campaign Page Locators/Activity Feed Page/no_ActivityFound_Text'), 30)

    No_Data_Text = WebUI.getText(findTestObject('Campaign Page Locators/Activity Feed Page/no_ActivityFound_Text'))

    assert No_Data_Text == EXPECTED_NO_DATA_TEXT
}

WebUI.click(findTestObject('Object Repository/Campaign Page Locators/Activity Feed Page/div_Clear'))

