import static com.kms.katalon.core.checkpoint.CheckpointFactory.findCheckpoint
import static com.kms.katalon.core.testcase.TestCaseFactory.findTestCase
import static com.kms.katalon.core.testdata.TestDataFactory.findTestData
import static com.kms.katalon.core.testobject.ObjectRepository.findTestObject
import static com.kms.katalon.core.testobject.ObjectRepository.findWindowsObject
import com.kms.katalon.core.checkpoint.Checkpoint as Checkpoint
import com.kms.katalon.core.cucumber.keyword.CucumberBuiltinKeywords as CucumberKW
import com.kms.katalon.core.mobile.keyword.MobileBuiltInKeywords as Mobile
import com.kms.katalon.core.model.FailureHandling as FailureHandling
import com.kms.katalon.core.testcase.TestCase as TestCase
import com.kms.katalon.core.testdata.TestData as TestData
import com.kms.katalon.core.testng.keyword.TestNGBuiltinKeywords as TestNGKW
import com.kms.katalon.core.testobject.TestObject as TestObject
import com.kms.katalon.core.webservice.keyword.WSBuiltInKeywords as WS
import com.kms.katalon.core.webui.keyword.WebUiBuiltInKeywords as WebUI
import com.kms.katalon.core.windows.keyword.WindowsBuiltinKeywords as Windows
import internal.GlobalVariable as GlobalVariable
import org.openqa.selenium.Keys as Keys
import com.kms.katalon.core.util.KeywordUtil as KeywordUtil
import org.openqa.selenium.By as By
import org.openqa.selenium.WebElement as WebElement
import com.kms.katalon.core.webui.driver.DriverFactory as DriverFactory

WebUI.callTestCase(findTestCase('Call function/Browser Launch'), [:], FailureHandling.STOP_ON_FAILURE)

Thread.sleep(4000)

WebUI.callTestCase(findTestCase('Call function/Login'), [:], FailureHandling.STOP_ON_FAILURE)

WebUI.click(findTestObject('New Folder/Page_Experience  Accounts/a_Automation account -Dont delete'))

WebUI.waitForElementPresent(findTestObject('Dashboard Page/Account Manager Dashboard'), 30)

String Actual_AccountName = WebUI.getText(findTestObject('Dashboard Page/Accounts Breadcum'))

if (Actual_AccountName.equals(Expected_AccountName)) {
    KeywordUtil.markPassed('The text value matches the expected value.')
} else {
    KeywordUtil.markFailed(((('The text value does not match. Expected: \'' + Actual_AccountName) + '\', but was: \'') + 
        Expected_AccountName) + '\'')
}

String Actual_AccManager_DashboardBreadcum = WebUI.getText(findTestObject('Dashboard Page/Account Manager Dashboard'))

if (Actual_AccManager_DashboardBreadcum.equals(Expected_AccManager_Dashboard_Breadcum)) {
    KeywordUtil.markPassed('The text value matches the expected value.')
} else {
    KeywordUtil.markFailed(((('The text value does not match. Expected: \'' + Actual_AccManager_DashboardBreadcum) + '\', but was: \'') + 
        Expected_AccManager_Dashboard_Breadcum) + '\'')
}

WebUI.click(findTestObject('Submenu Locators/Campaigns Submenu'))

WebUI.waitForElementVisible(findTestObject('Campaign Page Locators/Campaign Dashboard/Campaign Breadcum'), 30)

String Actual_CampaignBreadcum = WebUI.getText(findTestObject('Campaign Page Locators/Campaign Dashboard/Campaign Breadcum'))

if (Actual_CampaignBreadcum.equals(Expected_CampaignBreadcum)) {
    KeywordUtil.markPassed('The text value matches the expected value.')
} else {
    KeywordUtil.markFailed(((('The text value does not match. Expected: \'' + Actual_CampaignBreadcum) + '\', but was: \'') + 
        Expected_CampaignBreadcum) + '\'')
}

/*
List<WebElement> elements = WebUI.findElements(findTestObject('yourTestObject'))

elements.each { element ->
	// Validate each element
	assert element.displayed : "Element is not displayed: ${element}"
	assert element.enabled : "Element is not enabled: ${element}"
	// Additional validation checks
}
*/
WebUI.click(findTestObject('Campaign Page Locators/Campaign Activation Page/span_Total Surveys Sent'))

WebUI.click(findTestObject('Campaign Page Locators/Campaign Activation Page2/span_Total Responses'))

WebUI.click(findTestObject('Campaign Page Locators/Campaign Activation Page/span_Average Completion Rate'))

WebUI.click(findTestObject('Campaign Page Locators/Campaign Activation Page/span_Incomplete Surveys'))

