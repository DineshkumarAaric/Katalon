package internal

import com.kms.katalon.core.configuration.RunConfiguration
import com.kms.katalon.core.main.TestCaseMain


/**
 * This class is generated automatically by Katalon Studio and should not be modified or deleted.
 */
public class GlobalVariable {
     
    /**
     * <p></p>
     */
    public static Object Expected_AccountName
     
    /**
     * <p></p>
     */
    public static Object NewCampaignName
     
    /**
     * <p></p>
     */
    public static Object AccountsBreadcumText
     
    /**
     * <p></p>
     */
    public static Object ORG_NAME
     
    /**
     * <p></p>
     */
    public static Object EXPECTED_ACCOUNTMANAGER_DASHBOARD_BREADCUM
     
    /**
     * <p></p>
     */
    public static Object EXPECTED_CAMPAIGN_BREADCUM
     
    /**
     * <p></p>
     */
    public static Object AGENT_PROFILE_UPDATE_MSG
     
    /**
     * <p></p>
     */
    public static Object SRS_INITIAL
     
    /**
     * <p></p>
     */
    public static Object SRS_AFTER
     

    static {
        try {
            def selectedVariables = TestCaseMain.getGlobalVariables("default")
			selectedVariables += TestCaseMain.getGlobalVariables(RunConfiguration.getExecutionProfile())
            selectedVariables += TestCaseMain.getParsedValues(RunConfiguration.getOverridingParameters(), selectedVariables)
    
            Expected_AccountName = selectedVariables['Expected_AccountName']
            NewCampaignName = selectedVariables['NewCampaignName']
            AccountsBreadcumText = selectedVariables['AccountsBreadcumText']
            ORG_NAME = selectedVariables['ORG_NAME']
            EXPECTED_ACCOUNTMANAGER_DASHBOARD_BREADCUM = selectedVariables['EXPECTED_ACCOUNTMANAGER_DASHBOARD_BREADCUM']
            EXPECTED_CAMPAIGN_BREADCUM = selectedVariables['EXPECTED_CAMPAIGN_BREADCUM']
            AGENT_PROFILE_UPDATE_MSG = selectedVariables['AGENT_PROFILE_UPDATE_MSG']
            SRS_INITIAL = selectedVariables['SRS_INITIAL']
            SRS_AFTER = selectedVariables['SRS_AFTER']
            
        } catch (Exception e) {
            TestCaseMain.logGlobalVariableError(e)
        }
    }
}
